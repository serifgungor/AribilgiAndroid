package com.serifgungor.imageviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView ivResim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivResim = findViewById(R.id.ivResim);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.btnKedi){
            ivResim.setImageResource(R.drawable.kedi);
            //Toast.makeText(getApplicationContext(),"Kedi",Toast.LENGTH_LONG).show();
        }else if(view.getId()==R.id.btnKopek){
            ivResim.setImageResource(R.drawable.kopek);
            //Toast.makeText(getApplicationContext(), "Köpek", Toast.LENGTH_SHORT).show();
        }else if(view.getId()==R.id.btnKuzu){
            ivResim.setImageResource(R.drawable.kuzu);
            //Toast.makeText(getApplicationContext(), "Kuzu", Toast.LENGTH_SHORT).show();
        }else if(view.getId()==R.id.btnZurafa){
            ivResim.setImageResource(R.drawable.zurafa);
            //Toast.makeText(getApplicationContext(), "Zürafa", Toast.LENGTH_SHORT).show();
        }
    }
}