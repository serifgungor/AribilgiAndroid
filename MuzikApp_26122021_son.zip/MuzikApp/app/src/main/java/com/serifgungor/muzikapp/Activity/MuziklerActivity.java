package com.serifgungor.muzikapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.muzikapp.Adapter.MuzikAdapter;
import com.serifgungor.muzikapp.Model.Muzik;
import com.serifgungor.muzikapp.R;

import java.util.ArrayList;

public class MuziklerActivity extends AppCompatActivity {
    ListView listViewMuzikler;
    ArrayList<Muzik> muzikler = new ArrayList<>();
    MuzikAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muzikler);

        String kategoriAdi = getIntent().getStringExtra("kategori_adi");
        int kategoriId = getIntent().getIntExtra("kategori_id",1);
        String kategoriResim = getIntent().getStringExtra("kategori_resim");

        this.setTitle(kategoriAdi);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listViewMuzikler = findViewById(R.id.listViewMuzikler);
        if(kategoriId==1){
            muzikler.add(new Muzik(1,"Bu Saatten Sonra","İkilem",kategoriAdi,"","",""));
            muzikler.add(new Muzik(2,"Aşkın Mevsimi","Oğuzhan Koç",kategoriAdi,"","",""));
            muzikler.add(new Muzik(3,"Kendine Dünya","Merve Özbey",kategoriAdi,"","",""));
            muzikler.add(new Muzik(4,"Arıyorum","Edis",kategoriAdi,"","",""));
        }else if(kategoriId==2){
            muzikler.add(new Muzik(1,"Bu Saatten Sonra","İkilem",kategoriAdi,"","",""));
            muzikler.add(new Muzik(2,"Aşkın Mevsimi","Oğuzhan Koç",kategoriAdi,"","",""));
            muzikler.add(new Muzik(3,"Kendine Dünya","Merve Özbey",kategoriAdi,"","",""));
            muzikler.add(new Muzik(4,"Arıyorum","Edis",kategoriAdi,"","",""));
        }else if(kategoriId==3){
            muzikler.add(new Muzik(1,"UP","İnna",kategoriAdi,"https://i.ytimg.com/an/AtVPsPct4KM/17980867308302996381_mq.jpg?v=617bbdb6","","https://cdn104.mp3indirdur.info/indir.asp?ID=180514&cdn=cdn104&linkKontrol=66553797"));
            muzikler.add(new Muzik(2,"Beggin","Maneskin",kategoriAdi,"https://i1.sndcdn.com/artworks-fjrtMg5dOT11DBGk-mzXxQw-t500x500.jpg","","https://cdnguncelmp3indir.com/download/madcon/beggin/Madcon_Beggin.mp3"));
            muzikler.add(new Muzik(3,"Woman","Doja Cat",kategoriAdi,"https://i1.sndcdn.com/artworks-DRKdjL733c9GhWz6-Q3Nz1g-t500x500.jpg","","https://file-examples-com.github.io/uploads/2017/11/file_example_MP3_700KB.mp3"));
        }

        //for (int i = 1; i <= 50; i++) {

            //}
        adapter = new MuzikAdapter(muzikler,getApplicationContext());
        listViewMuzikler.setAdapter(adapter);
        listViewMuzikler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),MuzikDetayActivity.class);
                intent.putExtra("muzik",muzikler.get(i));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}