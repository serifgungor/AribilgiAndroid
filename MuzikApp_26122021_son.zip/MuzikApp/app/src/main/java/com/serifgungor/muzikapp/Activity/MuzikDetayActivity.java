package com.serifgungor.muzikapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.serifgungor.muzikapp.Helper.MusicPlayerView;
import com.serifgungor.muzikapp.Model.Muzik;
import com.serifgungor.muzikapp.R;

import java.io.IOException;

public class MuzikDetayActivity extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    MusicPlayerView mpv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muzik_detay);
        Muzik m = (Muzik) getIntent().getSerializableExtra("muzik");
        this.setTitle(m.getAd());

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(m.getMuzik_url());
        } catch (IOException e) {
            e.printStackTrace();
        }


        mpv = findViewById(R.id.mpv);
        if(!m.getResim().isEmpty()){
            mpv.setButtonColor(Color.DKGRAY);
            mpv.setProgressEmptyColor(Color.GRAY);
            mpv.setProgressLoadedColor(Color.BLUE);
            mpv.setTimeColor(Color.WHITE);

            mpv.setProgress(0);
            mpv.setCoverURL(m.getResim());
            mpv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mpv.isRotating()) {
                        mpv.stop();
                        mediaPlayer.pause();
                    } else {
                        mpv.start();

                        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        try {
                            mediaPlayer.prepare();
                            mpv.setProgress(0);
                            mpv.setMax(mediaPlayer.getDuration()/1000);
                            Log.d("UZUNLUK",""+mediaPlayer.getDuration());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        mediaPlayer.start();
                    }
                }
            });
        }

    }
}