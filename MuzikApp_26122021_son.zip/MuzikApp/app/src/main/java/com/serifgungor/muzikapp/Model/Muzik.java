package com.serifgungor.muzikapp.Model;

import java.io.Serializable;

public class Muzik implements Serializable {
    private int id;
    private String ad;
    private String sanatci;
    private String tur;
    private String resim;
    private String aciklama;
    private String muzik_url;

    public Muzik() {
    }

    public Muzik(int id, String ad, String sanatci, String tur, String resim, String aciklama, String muzik_url) {
        this.id = id;
        this.ad = ad;
        this.sanatci = sanatci;
        this.tur = tur;
        this.resim = resim;
        this.aciklama = aciklama;
        this.muzik_url = muzik_url;
    }

    public String getMuzik_url() {
        return muzik_url;
    }

    public void setMuzik_url(String muzik_url) {
        this.muzik_url = muzik_url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSanatci() {
        return sanatci;
    }

    public void setSanatci(String sanatci) {
        this.sanatci = sanatci;
    }

    public String getTur() {
        return tur;
    }

    public void setTur(String tur) {
        this.tur = tur;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }
}
