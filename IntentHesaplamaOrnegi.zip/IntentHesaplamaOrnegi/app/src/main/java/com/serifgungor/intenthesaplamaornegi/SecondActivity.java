package com.serifgungor.intenthesaplamaornegi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView tvTopla,tvCikar,tvCarp,tvBol;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tvTopla = findViewById(R.id.tvTopla);
        tvCikar = findViewById(R.id.tvCikar);
        tvCarp = findViewById(R.id.tvCarp);
        tvBol = findViewById(R.id.tvBol);

        //İntent ile int tipinde gelen veriyi yakalamak
        int sayi1 = getIntent().getIntExtra("sayi1",0);
        int sayi2 = getIntent().getIntExtra("sayi2",0);

        tvTopla.setText("Toplama sonucu: "+(sayi1+sayi2));
        tvCikar.setText("Çıkarma sonucu: "+(sayi1-sayi2));
        tvCarp.setText("Çarpma sonucu: "+(sayi1*sayi2));
        tvBol.setText("Bölme sonucu: "+(sayi1/sayi2));
    }
}