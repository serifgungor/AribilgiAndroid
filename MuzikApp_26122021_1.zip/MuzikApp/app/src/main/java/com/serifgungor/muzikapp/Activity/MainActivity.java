package com.serifgungor.muzikapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import com.serifgungor.muzikapp.Adapter.KategoriAdapter;
import com.serifgungor.muzikapp.Model.Kategori;
import com.serifgungor.muzikapp.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    GridView kategoriGrid;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    KategoriAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("MÜZİK APP");
        kategoriGrid = findViewById(R.id.kategoriler);

        kategoriler.add(new Kategori(1,"POP","https://images.unsplash.com/photo-1640374577565-4cd9da10bb80?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwzMHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        kategoriler.add(new Kategori(2,"TÜRKÇE","https://images.unsplash.com/photo-1593642634367-d91a135587b5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwyNnx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        kategoriler.add(new Kategori(3,"YABANCI","https://images.unsplash.com/photo-1640362625567-494b496aa236?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw0N3x8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        kategoriler.add(new Kategori(4,"SLOW","https://images.unsplash.com/photo-1640351960764-efb8d0850ae9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw1OXx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        kategoriler.add(new Kategori(5,"ROCK","https://images.unsplash.com/photo-1638913658828-afb88c3d4d11?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw3MHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        kategoriler.add(new Kategori(6,"RAP","https://images.unsplash.com/photo-1638913658828-afb88c3d4d11?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw3MHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&q=60"));
        adapter = new KategoriAdapter(kategoriler,getApplicationContext());
        kategoriGrid.setAdapter(adapter);

        kategoriGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),MuziklerActivity.class);
                intent.putExtra("kategori_id",kategoriler.get(i).getId());
                intent.putExtra("kategori_adi",kategoriler.get(i).getKategoriAdi());
                intent.putExtra("kategori_resim",kategoriler.get(i).getKategoriResimUrl());
                startActivity(intent);
            }
        });

    }
}