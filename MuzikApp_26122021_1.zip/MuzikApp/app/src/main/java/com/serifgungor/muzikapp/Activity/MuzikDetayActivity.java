package com.serifgungor.muzikapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.serifgungor.muzikapp.Helper.MusicPlayerView;
import com.serifgungor.muzikapp.Model.Muzik;
import com.serifgungor.muzikapp.R;

public class MuzikDetayActivity extends AppCompatActivity {

    MusicPlayerView mpv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muzik_detay);

        Muzik m = (Muzik) getIntent().getSerializableExtra("muzik");
        this.setTitle(m.getAd());
        mpv = findViewById(R.id.mpv);
        mpv.setButtonColor(Color.DKGRAY);
        mpv.setProgressEmptyColor(Color.GRAY);
        mpv.setProgressLoadedColor(Color.BLUE);
        mpv.setTimeColor(Color.WHITE);
        mpv.setMax(320);
        mpv.setProgress(10);
        mpv.setCoverURL(m.getResim());
        mpv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mpv.isRotating()) {
                    mpv.stop();
                } else {
                    mpv.start();
                }
            }
        });
    }
}