package com.serifgungor.muzikapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.muzikapp.Model.Muzik;
import com.serifgungor.muzikapp.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MuzikAdapter extends BaseAdapter {
    private ArrayList<Muzik> muzikler;
    private Context context;
    private LayoutInflater layoutInflater;

    public MuzikAdapter(ArrayList<Muzik> muzikler, Context context) {
        this.muzikler = muzikler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return muzikler.size();
    }

    @Override
    public Muzik getItem(int i) {
        return muzikler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.muzik_row,null);

        CircleImageView resim = v.findViewById(R.id.muzik_resim);
        TextView tvBaslik = v.findViewById(R.id.tvMuzikAdi);
        TextView tvSanatci = v.findViewById(R.id.tvSanatciAdi);

        tvBaslik.setText(muzikler.get(i).getAd());
        tvSanatci.setText(muzikler.get(i).getSanatci());
        Glide.with(v.getContext()).load(muzikler.get(i).getResim()).into(resim);


        return v;
    }
}
