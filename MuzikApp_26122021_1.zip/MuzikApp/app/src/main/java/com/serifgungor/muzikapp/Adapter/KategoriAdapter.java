package com.serifgungor.muzikapp.Adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.serifgungor.muzikapp.Model.Kategori;
import com.serifgungor.muzikapp.R;

import java.util.ArrayList;

public class KategoriAdapter extends BaseAdapter {

    private ArrayList<Kategori> kategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public KategoriAdapter(ArrayList<Kategori> kategoriler, Context context) {
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Kategori getItem(int i) {
        return kategoriler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return kategoriler.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.kategori_row,null);
        CardView cv = v.findViewById(R.id.cardKategori);
        TextView tv = v.findViewById(R.id.txtCardKategori);

        tv.setText(kategoriler.get(i).getKategoriAdi());
        Glide
                .with(v.getContext())
                .asDrawable()
                .load(kategoriler.get(i).getKategoriResimUrl())
                .into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        cv.setBackground(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });



        return v;
    }
}
