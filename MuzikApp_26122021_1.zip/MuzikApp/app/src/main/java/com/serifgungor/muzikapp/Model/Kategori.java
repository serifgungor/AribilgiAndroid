package com.serifgungor.muzikapp.Model;

public class Kategori {
    private int id;
    private String kategoriAdi;
    private String kategoriResimUrl;

    public Kategori() {
    }

    public Kategori(int id, String kategoriAdi, String kategoriResimUrl) {
        this.id = id;
        this.kategoriAdi = kategoriAdi;
        this.kategoriResimUrl = kategoriResimUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getKategoriResimUrl() {
        return kategoriResimUrl;
    }

    public void setKategoriResimUrl(String kategoriResimUrl) {
        this.kategoriResimUrl = kategoriResimUrl;
    }
}
