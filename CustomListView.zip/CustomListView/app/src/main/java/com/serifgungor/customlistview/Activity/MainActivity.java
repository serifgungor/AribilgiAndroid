package com.serifgungor.customlistview.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.customlistview.Adapter.SanatciAdapter;
import com.serifgungor.customlistview.Model.Unlu;
import com.serifgungor.customlistview.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SanatciAdapter adapter;
    ArrayList<Unlu> unluler = new ArrayList<Unlu>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        //String adi, String resim, String muzikTuru
        unluler.add(new Unlu("Tarkan","https://i2.milimaj.com/i/milliyet/75/770x0/6026631a5542811e6cf56215.jpg","POP"));
        unluler.add(new Unlu("Sezen Aksu","https://i.scdn.co/image/ab67706f00000003aa15d059edbad43d81df0ebd","Slow"));
        unluler.add(new Unlu("Sertap Erener","https://upload.wikimedia.org/wikipedia/tr/7/75/Sertab_Erener_alb%C3%BCm.png","POP"));


        adapter = new SanatciAdapter(unluler,getApplicationContext());
        listView.setAdapter(adapter);

    }
}