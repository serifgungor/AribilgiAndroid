package com.serifgungor.customlistview.Model;

public class Unlu {

    private String adi;
    private String resim;
    private String muzikTuru;

    public Unlu() {
    }

    public Unlu(String adi, String resim, String muzikTuru) {
        this.adi = adi;
        this.resim = resim;
        this.muzikTuru = muzikTuru;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getMuzikTuru() {
        return muzikTuru;
    }

    public void setMuzikTuru(String muzikTuru) {
        this.muzikTuru = muzikTuru;
    }
}
