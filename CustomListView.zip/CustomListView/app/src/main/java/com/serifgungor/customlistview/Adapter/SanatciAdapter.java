package com.serifgungor.customlistview.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.customlistview.Model.Unlu;
import com.serifgungor.customlistview.R;

import java.util.ArrayList;

public class SanatciAdapter extends BaseAdapter {

    private ArrayList<Unlu> unluler;
    private Context context;
    private LayoutInflater layoutInflater;

    public SanatciAdapter(ArrayList<Unlu> unluler, Context context) {
        this.unluler = unluler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return unluler.size();
    }

    @Override
    public Unlu getItem(int i) {
        return unluler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.satir_goruntusu,null);
        TextView tvSanatciAdi = v.findViewById(R.id.tvSanatciAdi);
        TextView tvMuzikTuru = v.findViewById(R.id.tvMuzikTuru);
        ImageView ivResim = v.findViewById(R.id.ivSanatciResim);

        tvSanatciAdi.setText(unluler.get(i).getAdi());
        tvMuzikTuru.setText(unluler.get(i).getMuzikTuru());
        Glide.with(v.getContext()).load(unluler.get(i).getResim()).into(ivResim);

        return v;
    }
}
