package com.serifgungor.sorubankasi.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.sorubankasi.Helper.DatabaseHelper;
import com.serifgungor.sorubankasi.Model.Konu;
import com.serifgungor.sorubankasi.Model.KullaniciYanitlari;
import com.serifgungor.sorubankasi.Model.Soru;
import com.serifgungor.sorubankasi.Model.Yanit;
import com.serifgungor.sorubankasi.R;

import java.io.IOException;
import java.util.ArrayList;

public class SorularActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    ArrayList<Soru> sorular = new ArrayList<Soru>();

    Button btnOncekiSoru, btnSonrakiSoru, btnBitir;
    RadioGroup rdYanit;
    RadioButton rda, rdb, rdc, rdd, rde;
    TextView tvBaslik;
    int suanki_index = 0, suanki_soru_id = 0;
    int max_index = 0;
    Konu konu;


    public void yanitlariDoldur() {
        tvBaslik.setText(sorular.get(suanki_index).getSoru_baslik());
        rda.setText(sorular.get(suanki_index).getSoru_yanit_a());
        rdb.setText(sorular.get(suanki_index).getSoru_yanit_b());
        rdc.setText(sorular.get(suanki_index).getSoru_yanit_c());
        rdd.setText(sorular.get(suanki_index).getSoru_yanit_d());
        rde.setText(sorular.get(suanki_index).getSoru_yanit_e());
        suanki_soru_id = sorular.get(suanki_index).getId();
        rdYanit.clearCheck();
    }

    @SuppressLint("Range")
    public ArrayList<Yanit> yanitlariGetirDb() {
        ArrayList<Yanit> y = new ArrayList<>();
        Cursor c = db.rawQuery("select * from Soru_Yanit where konu_id=" + konu.getKonu_id(), null);
        while (c.moveToNext()) {
            y.add(new Yanit(c.getInt(c.getColumnIndex("soru_id")), c.getString(c.getColumnIndex("yanit_harf"))));
        }
        return y;
    }

    public void yanitiKaydetDb() {
        String harf = "";
        if (rda.isChecked()) {
            harf = "a";
        } else if (rdb.isChecked()) {
            harf = "b";
        } else if (rdc.isChecked()) {
            harf = "c";
        } else if (rdd.isChecked()) {
            harf = "d";
        } else if (rde.isChecked()) {
            harf = "e";
        }
        Cursor c = db.rawQuery("select * from Soru_Yanit where soru_id=" + suanki_soru_id, null);
        boolean yanit_kayitlimi = false;
        while (c.moveToNext()) {
            yanit_kayitlimi = true;
        }
        if (yanit_kayitlimi == false) {
            db.execSQL("INSERT INTO Soru_Yanit (konu_id,soru_id,yanit_harf) VALUES (" + konu.getKonu_id() + "," + suanki_soru_id + ",'" + harf + "')");
        } else {
            db.execSQL("UPDATE Soru_Yanit set yanit_harf='" + harf + "' where soru_id=" + suanki_soru_id);
        }
    }


    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sorular);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        konu = (Konu) getIntent().getSerializableExtra("konu");
        this.setTitle("Konu: " + konu.getBaslik());

        tvBaslik = findViewById(R.id.tvSoruBaslik);
        btnOncekiSoru = findViewById(R.id.btnOncekiSoru);
        btnSonrakiSoru = findViewById(R.id.btnSonrakiSoru);
        btnBitir = findViewById(R.id.btnBitir);
        rdYanit = findViewById(R.id.rdYanit);
        rda = findViewById(R.id.rdYanitA);
        rdb = findViewById(R.id.rdYanitB);
        rdc = findViewById(R.id.rdYanitC);
        rdd = findViewById(R.id.rdYanitD);
        rde = findViewById(R.id.rdYanitE);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getWritableDatabase();

            Cursor c = db.rawQuery(
                    "SELECT * from Soru where konu_id = " + konu.getKonu_id(),
                    null
            );
            while (c.moveToNext()) {
                sorular.add(new Soru(
                        c.getInt(c.getColumnIndex("id")),
                        c.getInt(c.getColumnIndex("konu_id")),
                        c.getString(c.getColumnIndex("soru_baslik")),
                        c.getString(c.getColumnIndex("soru_yanit_a")),
                        c.getString(c.getColumnIndex("soru_yanit_b")),
                        c.getString(c.getColumnIndex("soru_yanit_c")),
                        c.getString(c.getColumnIndex("soru_yanit_d")),
                        c.getString(c.getColumnIndex("soru_yanit_e")),
                        c.getString(c.getColumnIndex("soru_yanit_harf")),
                        c.getInt(c.getColumnIndex("soru_puan"))
                ));
            }
            max_index = c.getCount()-1;

            yanitlariDoldur();


        } catch (IOException e) {
            e.printStackTrace();
        }

        btnOncekiSoru.setVisibility(View.INVISIBLE);
        btnBitir.setVisibility(View.INVISIBLE);

        btnBitir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                for (int i = 0; i < yanitlariGetirDb().size(); i++) {
                    Log.d("YANITLAR", yanitlariGetirDb().get(i).getSoru_id() + " " + yanitlariGetirDb().get(i).getYanit_harf());
                }

                Intent intent = new Intent(getApplicationContext(),SonucActivity.class);
                KullaniciYanitlari ky = new KullaniciYanitlari(yanitlariGetirDb());
                intent.putExtra("yanitlar",ky);
                intent.putExtra("konu",konu);
                startActivity(intent);
            }
        });

        btnOncekiSoru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (suanki_index == 0) {
                    suanki_index = 0;
                    btnOncekiSoru.setVisibility(View.INVISIBLE);
                } else if (suanki_index > 0) {
                    suanki_index -= 1;
                    if (suanki_index == 0) {
                        btnOncekiSoru.setVisibility(View.INVISIBLE);
                    }
                    if (btnSonrakiSoru.getText().equals("Bitir")) {
                        btnSonrakiSoru.setText("Sonraki Soru");
                    }
                }
                yanitlariDoldur();
                for (Yanit yanit : yanitlariGetirDb()) {
                    if (yanit.getSoru_id() == suanki_soru_id) {
                        if (yanit.getYanit_harf().equalsIgnoreCase("a")) {
                            rda.setChecked(true);
                        } else if (yanit.getYanit_harf().equalsIgnoreCase("b")) {
                            rdb.setChecked(true);
                        } else if (yanit.getYanit_harf().equalsIgnoreCase("c")) {
                            rdc.setChecked(true);
                        } else if (yanit.getYanit_harf().equalsIgnoreCase("d")) {
                            rdd.setChecked(true);
                        } else if (yanit.getYanit_harf().equalsIgnoreCase("e")) {
                            rde.setChecked(true);
                        }
                    }
                }
            }
        });

        btnSonrakiSoru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("YANITLAR",""+suanki_index);

                if(suanki_index==max_index){
                    btnSonrakiSoru.setVisibility(View.INVISIBLE);
                    btnBitir.setVisibility(View.VISIBLE);
                }
                if (suanki_index < max_index) {
                    suanki_index += 1;

                    btnOncekiSoru.setVisibility(View.VISIBLE);
                    yanitiKaydetDb();
                    yanitlariDoldur();
                    for (Yanit yanit : yanitlariGetirDb()) {
                        if (yanit.getSoru_id() == suanki_soru_id) {
                            if (yanit.getYanit_harf().equalsIgnoreCase("a")) {
                                rda.setChecked(true);
                            } else if (yanit.getYanit_harf().equalsIgnoreCase("b")) {
                                rdb.setChecked(true);
                            } else if (yanit.getYanit_harf().equalsIgnoreCase("c")) {
                                rdc.setChecked(true);
                            } else if (yanit.getYanit_harf().equalsIgnoreCase("d")) {
                                rdd.setChecked(true);
                            } else if (yanit.getYanit_harf().equalsIgnoreCase("e")) {
                                rde.setChecked(true);
                            }
                        }
                    }
                }



            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}