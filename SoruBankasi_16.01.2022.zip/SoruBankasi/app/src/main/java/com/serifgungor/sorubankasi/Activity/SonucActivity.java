package com.serifgungor.sorubankasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.serifgungor.sorubankasi.Helper.DatabaseHelper;
import com.serifgungor.sorubankasi.Model.Konu;
import com.serifgungor.sorubankasi.Model.KullaniciYanitlari;
import com.serifgungor.sorubankasi.Model.Soru;
import com.serifgungor.sorubankasi.Model.Yanit;
import com.serifgungor.sorubankasi.R;

import java.io.IOException;
import java.util.ArrayList;

public class SonucActivity extends AppCompatActivity {
    ArrayList<Yanit> yanitlar = new ArrayList<>();
    ArrayList<Soru> sorular = new ArrayList<Soru>();
    LinearLayout linearDogru,linearYanlis;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Konu konu;
    KullaniciYanitlari ky;

    ArrayList<Yanit> dogruYanitlar = new ArrayList<>();
    ArrayList<Yanit> yanlisYanitlar = new ArrayList<>();

    @SuppressLint("Range")
    public void yanitlariGetir(){

        Cursor c = db.rawQuery("select * from Soru where konu_id="+konu.getKonu_id(),null);
        while (c.moveToNext()){
            sorular.add(new Soru(
                    c.getInt(c.getColumnIndex("id")),
                    c.getInt(c.getColumnIndex("konu_id")),
                    c.getString(c.getColumnIndex("soru_baslik")),
                    c.getString(c.getColumnIndex("soru_yanit_a")),
                    c.getString(c.getColumnIndex("soru_yanit_b")),
                    c.getString(c.getColumnIndex("soru_yanit_c")),
                    c.getString(c.getColumnIndex("soru_yanit_d")),
                    c.getString(c.getColumnIndex("soru_yanit_e")),
                    c.getString(c.getColumnIndex("soru_yanit_harf")),
                    c.getInt(c.getColumnIndex("soru_puan"))
            ));

            /*
            Her hangi bir sorunun değeri, yanıtlar tablosundaki belirli bir sorunun değeri ile eşleşiyor mu
             */
            for (int i = 0; i < yanitlar.size(); i++) {
                if(yanitlar.get(i).getSoru_id()==c.getInt(c.getColumnIndex("id"))){
                    if(yanitlar.get(i).getYanit_harf().equals(c.getString(c.getColumnIndex("soru_yanit_harf")))){
                        dogruYanitlar.add(new Yanit(yanitlar.get(i).getSoru_id(),yanitlar.get(i).getYanit_harf()));
                    }else{
                        yanlisYanitlar.add(new Yanit(yanitlar.get(i).getSoru_id(),yanitlar.get(i).getYanit_harf()));
                    }
                }
            }

        }

    }

    public void verileriDoldur(){
        for (int i = 0; i < dogruYanitlar.size(); i++) {
            TextView tv = new TextView(getApplicationContext());
            tv.setTextSize(20f);
            tv.setText("Soru: "+dogruYanitlar.get(i).getSoru_id() + " - " + dogruYanitlar.get(i).getYanit_harf());
            linearDogru.addView(tv);
        }

        for (int i = 0; i < yanlisYanitlar.size(); i++) {
            TextView tv = new TextView(getApplicationContext());
            tv.setTextSize(20f);
            for (int j = 0; j < sorular.size(); j++) {
                if(yanlisYanitlar.get(i).getSoru_id()==sorular.get(j).getId()){
                    tv.setText("Soru: "+yanlisYanitlar.get(i).getSoru_id() + " Yanıtınız: " + yanlisYanitlar.get(i).getYanit_harf() + " Doğru Yanıt: "+sorular.get(j).getSoru_yanit_harf());
                }
            }
            linearYanlis.addView(tv);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonuc);

        konu = (Konu)getIntent().getSerializableExtra("konu");
        ky = (KullaniciYanitlari) getIntent().getSerializableExtra("yanitlar");
        yanitlar = ky.getYanitlar();

        linearDogru = findViewById(R.id.linearDogrular);
        linearYanlis = findViewById(R.id.linearYanlislar);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
            yanitlariGetir();
            verileriDoldur();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}