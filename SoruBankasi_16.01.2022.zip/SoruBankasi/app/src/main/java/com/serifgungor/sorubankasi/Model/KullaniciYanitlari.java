package com.serifgungor.sorubankasi.Model;

import java.io.Serializable;
import java.util.ArrayList;

public class KullaniciYanitlari implements Serializable {
    private ArrayList<Yanit> yanitlar;

    public KullaniciYanitlari() {
    }

    public KullaniciYanitlari(ArrayList<Yanit> yanitlar) {
        this.yanitlar = yanitlar;
    }

    public ArrayList<Yanit> getYanitlar() {
        return yanitlar;
    }

    public void setYanitlar(ArrayList<Yanit> yanitlar) {
        this.yanitlar = yanitlar;
    }
}
