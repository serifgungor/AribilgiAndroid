package com.serifgungor.sorubankasi.Model;

import java.io.Serializable;

public class Yanit implements Serializable {
    private int soru_id;
    private String yanit_harf;

    public Yanit() {
    }

    public Yanit(int soru_id, String yanit_harf) {
        this.soru_id = soru_id;
        this.yanit_harf = yanit_harf;
    }

    public int getSoru_id() {
        return soru_id;
    }

    public void setSoru_id(int soru_id) {
        this.soru_id = soru_id;
    }

    public String getYanit_harf() {
        return yanit_harf;
    }

    public void setYanit_harf(String yanit_harf) {
        this.yanit_harf = yanit_harf;
    }

    @Override
    public String toString() {
        return "Yanit{" +
                "soru_id=" + soru_id +
                ", yanit_harf='" + yanit_harf + '\'' +
                '}';
    }
}
