package com.serifgungor.sorubankasi.Model;

import java.io.Serializable;

public class Konu implements Serializable {
    private int konu_id;
    private int kategori_id;
    private String baslik;

    public Konu() {
    }

    public Konu(int konu_id, int kategori_id, String baslik) {
        this.konu_id = konu_id;
        this.kategori_id = kategori_id;
        this.baslik = baslik;
    }

    public int getKonu_id() {
        return konu_id;
    }

    public void setKonu_id(int konu_id) {
        this.konu_id = konu_id;
    }

    public int getKategori_id() {
        return kategori_id;
    }

    public void setKategori_id(int kategori_id) {
        this.kategori_id = kategori_id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    @Override
    public String toString() {
        return baslik;
    }
}
