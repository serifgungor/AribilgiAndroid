package com.serifgungor.muzikapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.serifgungor.muzikapp.R;

public class MuziklerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muzikler);

        String kategoriAdi = getIntent().getStringExtra("kategori_adi");
        int kategoriId = getIntent().getIntExtra("kategori_id",1);
        String kategoriResim = getIntent().getStringExtra("kategori_resim");

        this.setTitle(kategoriAdi);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}