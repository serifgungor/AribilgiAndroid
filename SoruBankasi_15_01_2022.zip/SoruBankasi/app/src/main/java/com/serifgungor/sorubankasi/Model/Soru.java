package com.serifgungor.sorubankasi.Model;

import java.io.Serializable;

public class Soru implements Serializable {
    private int id;
    private int konu_id;
    private String soru_baslik;
    private String soru_yanit_a;
    private String soru_yanit_b;
    private String soru_yanit_c;
    private String soru_yanit_d;
    private String soru_yanit_e;
    private String soru_yanit_harf;
    private int soru_puan;


    public Soru() {
    }

    public Soru(int id, int konu_id, String soru_baslik, String soru_yanit_a, String soru_yanit_b, String soru_yanit_c, String soru_yanit_d, String soru_yanit_e, String soru_yanit_harf, int soru_puan) {
        this.id = id;
        this.konu_id = konu_id;
        this.soru_baslik = soru_baslik;
        this.soru_yanit_a = soru_yanit_a;
        this.soru_yanit_b = soru_yanit_b;
        this.soru_yanit_c = soru_yanit_c;
        this.soru_yanit_d = soru_yanit_d;
        this.soru_yanit_e = soru_yanit_e;
        this.soru_yanit_harf = soru_yanit_harf;
        this.soru_puan = soru_puan;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKonu_id() {
        return konu_id;
    }

    public void setKonu_id(int konu_id) {
        this.konu_id = konu_id;
    }

    public String getSoru_baslik() {
        return soru_baslik;
    }

    public void setSoru_baslik(String soru_baslik) {
        this.soru_baslik = soru_baslik;
    }

    public String getSoru_yanit_a() {
        return soru_yanit_a;
    }

    public void setSoru_yanit_a(String soru_yanit_a) {
        this.soru_yanit_a = soru_yanit_a;
    }

    public String getSoru_yanit_b() {
        return soru_yanit_b;
    }

    public void setSoru_yanit_b(String soru_yanit_b) {
        this.soru_yanit_b = soru_yanit_b;
    }

    public String getSoru_yanit_c() {
        return soru_yanit_c;
    }

    public void setSoru_yanit_c(String soru_yanit_c) {
        this.soru_yanit_c = soru_yanit_c;
    }

    public String getSoru_yanit_d() {
        return soru_yanit_d;
    }

    public void setSoru_yanit_d(String soru_yanit_d) {
        this.soru_yanit_d = soru_yanit_d;
    }

    public String getSoru_yanit_e() {
        return soru_yanit_e;
    }

    public void setSoru_yanit_e(String soru_yanit_e) {
        this.soru_yanit_e = soru_yanit_e;
    }

    public String getSoru_yanit_harf() {
        return soru_yanit_harf;
    }

    public void setSoru_yanit_harf(String soru_yanit_harf) {
        this.soru_yanit_harf = soru_yanit_harf;
    }

    public int getSoru_puan() {
        return soru_puan;
    }

    public void setSoru_puan(int soru_puan) {
        this.soru_puan = soru_puan;
    }
}
