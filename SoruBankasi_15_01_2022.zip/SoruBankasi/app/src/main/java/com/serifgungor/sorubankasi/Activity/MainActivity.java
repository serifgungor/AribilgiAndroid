package com.serifgungor.sorubankasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.serifgungor.sorubankasi.Helper.DatabaseHelper;
import com.serifgungor.sorubankasi.Model.Kategori;
import com.serifgungor.sorubankasi.Model.Konu;
import com.serifgungor.sorubankasi.R;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter<Kategori> kategoriAdapter;
    ArrayAdapter<Konu> konuAdapter;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    ArrayList<Konu> konular = new ArrayList<>();

    Button btnSorulariGetir;
    Spinner spKategori,spKonu;

    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getWritableDatabase();

            /*
            Cursor sınıfı select sorgularını çalıştırıp satır satır, bütün kolon değerlerini
            gezebilmemize olanak tanır.
             */
            kategoriler.add(new Kategori(0,"-",""));
            Cursor c = db.rawQuery("SELECT * from Kategori",null);
            while (c.moveToNext()){
                kategoriler.add(new Kategori(
                        c.getInt(c.getColumnIndex("id")),
                        c.getString(c.getColumnIndex("baslik")),
                        c.getString(c.getColumnIndex("resim"))
                ));
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

        spKategori = findViewById(R.id.spKategori);
        spKonu = findViewById(R.id.spKonu);
        btnSorulariGetir = findViewById(R.id.btnSorulariGetir);

        kategoriAdapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                kategoriler
        );

        spKategori.setAdapter(kategoriAdapter);

        spKategori.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                Cursor konu = db.rawQuery(
                        "SELECT * from Konu where kategori_id = "+kategoriler.get(i).getId(),
                        null
                );
                konular.clear();
                konular.add(new Konu(
                        0,0,"-"
                ));
                while (konu.moveToNext()){
                    konular.add(new Konu(
                            konu.getInt(konu.getColumnIndex("konu_id")),
                            konu.getInt(konu.getColumnIndex("kategori_id")),
                            konu.getString(konu.getColumnIndex("baslik"))
                    ));
                }
                konuAdapter = new ArrayAdapter<>(
                        getApplicationContext(),
                        android.R.layout.simple_spinner_dropdown_item,
                        konular
                );
                spKonu.setAdapter(konuAdapter);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnSorulariGetir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean b = false;
                if("-".equals(spKategori.getSelectedItem().toString())){
                    b = false;
                }else{
                    b = true;
                }

                if("-".equals(spKonu.getSelectedItem().toString())){
                    b = false;
                }else{
                    b = true;
                }

                if(b==false){
                    Toast.makeText(
                            getApplicationContext(),
                            "Kategori ve Konu seçilmelidir",
                            Toast.LENGTH_LONG
                    ).show();
                }else{
                    //SorularActivity sayfasına git
                    Intent intent = new Intent(getApplicationContext(),SorularActivity.class);
                    intent.putExtra("konu",konular.get(spKonu.getSelectedItemPosition()));
                    startActivity(intent);
                }
            }
        });




    }
}