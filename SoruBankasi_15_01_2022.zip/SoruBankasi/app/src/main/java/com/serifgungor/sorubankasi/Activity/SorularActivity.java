package com.serifgungor.sorubankasi.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.serifgungor.sorubankasi.Helper.DatabaseHelper;
import com.serifgungor.sorubankasi.Model.Konu;
import com.serifgungor.sorubankasi.Model.Soru;
import com.serifgungor.sorubankasi.R;

import java.io.IOException;
import java.util.ArrayList;

public class SorularActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    ArrayList<Soru> sorular = new ArrayList<Soru>();

    Button btnOncekiSoru,btnSonrakiSoru;
    RadioButton rda,rdb,rdc,rdd,rde;
    TextView tvBaslik;
    int suanki_index = 0;
    int max_index = 0;

    public void yanitlariDoldur(){
        tvBaslik.setText(sorular.get(suanki_index).getSoru_baslik());
        rda.setText(sorular.get(suanki_index).getSoru_yanit_a());
        rdb.setText(sorular.get(suanki_index).getSoru_yanit_b());
        rdc.setText(sorular.get(suanki_index).getSoru_yanit_c());
        rdd.setText(sorular.get(suanki_index).getSoru_yanit_d());
        rde.setText(sorular.get(suanki_index).getSoru_yanit_e());
        rda.setChecked(false);
        rdb.setChecked(false);
        rdc.setChecked(false);
        rdd.setChecked(false);
        rde.setChecked(false);
        rda.clearFocus();
    }

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sorular);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Konu konu = (Konu)getIntent().getSerializableExtra("konu");
        this.setTitle("Konu: "+konu.getBaslik());

        tvBaslik = findViewById(R.id.tvSoruBaslik);
        btnOncekiSoru = findViewById(R.id.btnOncekiSoru);
        btnSonrakiSoru = findViewById(R.id.btnSonrakiSoru);
        rda = findViewById(R.id.rdYanitA);
        rdb = findViewById(R.id.rdYanitB);
        rdc = findViewById(R.id.rdYanitC);
        rdd = findViewById(R.id.rdYanitD);
        rde = findViewById(R.id.rdYanitE);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getWritableDatabase();

            Cursor c = db.rawQuery(
                    "SELECT * from Soru where konu_id = "+konu.getKonu_id(),
                    null
            );
            while (c.moveToNext()){
                sorular.add(new Soru(
                        c.getInt(c.getColumnIndex("id")),
                        c.getInt(c.getColumnIndex("konu_id")),
                        c.getString(c.getColumnIndex("soru_baslik")),
                        c.getString(c.getColumnIndex("soru_yanit_a")),
                        c.getString(c.getColumnIndex("soru_yanit_b")),
                        c.getString(c.getColumnIndex("soru_yanit_c")),
                        c.getString(c.getColumnIndex("soru_yanit_d")),
                        c.getString(c.getColumnIndex("soru_yanit_e")),
                        c.getString(c.getColumnIndex("soru_yanit_harf")),
                        c.getInt(c.getColumnIndex("soru_puan"))
                ));
            }
            max_index = c.getCount();

            yanitlariDoldur();


        } catch (IOException e) {
            e.printStackTrace();
        }

        btnOncekiSoru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(0<=suanki_index){
                    suanki_index = 0;
                }else{
                    suanki_index -= 1;
                }
                yanitlariDoldur();
            }
        });

        btnSonrakiSoru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(suanki_index>(max_index-1)){
                    suanki_index = max_index-1;
                    btnSonrakiSoru.setText("Bitir");
                }else{
                    suanki_index += 1;
                }
                yanitlariDoldur();
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}