package com.example.turkceingilizcesozluk.Model;

import java.io.Serializable;

public class Favori implements Serializable {
    private int id;
    private int kelime_id;

    public Favori() {
    }

    public Favori(int id, int kelime_id) {
        this.id = id;
        this.kelime_id = kelime_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKelime_id() {
        return kelime_id;
    }

    public void setKelime_id(int kelime_id) {
        this.kelime_id = kelime_id;
    }
}
