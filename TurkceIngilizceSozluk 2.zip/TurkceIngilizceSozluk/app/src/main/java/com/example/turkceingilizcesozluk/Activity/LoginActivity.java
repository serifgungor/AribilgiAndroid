package com.example.turkceingilizcesozluk.Activity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.turkceingilizcesozluk.Helper.DatabaseHelper;
import com.example.turkceingilizcesozluk.R;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {

    EditText etEmailLogin,etSifreLogin,etEmailRegister,etSifreRegister;
    Button btnLogin,btnRegister;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    public boolean kullaniciGiris(String email,String sifre){
        boolean b = false;
        String sorgu = "select * from Kullanici where email='"+email+"' and password='"+sifre+"'";
        Cursor c = db.rawQuery(sorgu,null);
        if(c.getCount()>0)
           b = true;
        return b;
    }
    public int kullaniciKayit(String email,String sifre){
        //String sorgu = "insert into Kullanici (email,password) VALUES ('"+email+"','"+sifre+"')";
        //db.execSQL(sorgu);
        /*
        -1 - Kullanıcı kayıtlıdır
        1 - Kayıt başarılı
        2 - hata oluştu
         */
        String sorgu = "select * from Kullanici where email='"+email+"'";
        Cursor c = db.rawQuery(sorgu,null);
        if(c.getCount()>0){
            return -1;
        }else{
            ContentValues values = new ContentValues();
            values.put("email",email);
            values.put("password",sifre);
            long l = db.insert("Kullanici",null,values);
            if(l>0){
                return 1;
            }else{
                return 2;
            }
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        etEmailLogin = findViewById(R.id.etGirisEmail);
        etSifreLogin = findViewById(R.id.etGirisSifre);
        etEmailRegister = findViewById(R.id.etKayitEmail);
        etSifreRegister = findViewById(R.id.etKayitSifre);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(kullaniciGiris(etEmailLogin.getText().toString(),etSifreLogin.getText().toString())){
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "Kullanıcı adı veya Şifre hatalı", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int islemSonuc = kullaniciKayit(etEmailRegister.getText().toString(),etSifreRegister.getText().toString());
                if(islemSonuc==1){
                    Toast.makeText(getApplicationContext(), "Kayıt işlemi başarılı", Toast.LENGTH_SHORT).show();
                }else if(islemSonuc==2){
                    Toast.makeText(getApplicationContext(), "Kayıt başarısız", Toast.LENGTH_SHORT).show();
                }else if(islemSonuc==-1){
                    Toast.makeText(getApplicationContext(), "Kullanıcı zaten kayıtlı", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}