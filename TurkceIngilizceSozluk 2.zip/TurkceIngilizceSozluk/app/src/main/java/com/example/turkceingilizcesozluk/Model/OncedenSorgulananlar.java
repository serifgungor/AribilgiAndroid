package com.example.turkceingilizcesozluk.Model;

import java.io.Serializable;

public class OncedenSorgulananlar implements Serializable {
    private int id;
    private int source_lang_id;
    private int translate_lang_id;
    private String kelime;
    private String sonuc;
    private String tarih;

    public OncedenSorgulananlar() {
    }

    public OncedenSorgulananlar(int id, int source_lang_id, int translate_lang_id, String kelime, String sonuc, String tarih) {
        this.id = id;
        this.source_lang_id = source_lang_id;
        this.translate_lang_id = translate_lang_id;
        this.kelime = kelime;
        this.sonuc = sonuc;
        this.tarih = tarih;
    }

    public int getSource_lang_id() {
        return source_lang_id;
    }

    public void setSource_lang_id(int source_lang_id) {
        this.source_lang_id = source_lang_id;
    }

    public int getTranslate_lang_id() {
        return translate_lang_id;
    }

    public void setTranslate_lang_id(int translate_lang_id) {
        this.translate_lang_id = translate_lang_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKelime() {
        return kelime;
    }

    public void setKelime(String kelime) {
        this.kelime = kelime;
    }

    public String getSonuc() {
        return sonuc;
    }

    public void setSonuc(String sonuc) {
        this.sonuc = sonuc;
    }

    public String getTarih() {
        return tarih;
    }

    public void setTarih(String tarih) {
        this.tarih = tarih;
    }
}
