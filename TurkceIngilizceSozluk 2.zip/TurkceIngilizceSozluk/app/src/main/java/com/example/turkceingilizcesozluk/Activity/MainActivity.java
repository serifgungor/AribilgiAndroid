package com.example.turkceingilizcesozluk.Activity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.turkceingilizcesozluk.Adapter.RecceRecycleAdapt;
import com.example.turkceingilizcesozluk.Helper.DatabaseHelper;
import com.example.turkceingilizcesozluk.Model.Dil;
import com.example.turkceingilizcesozluk.Model.OncedenSorgulananlar;
import com.example.turkceingilizcesozluk.R;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.chrono.ChronoLocalDate;
import java.time.chrono.ChronoLocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    ArrayAdapter<Dil> diller;
    Spinner spSource,spResult;
    EditText etResult,etSearch;

    RecceRecycleAdapt adapt;
    RecyclerView recyclerViewArananlar;
    ArrayList<OncedenSorgulananlar> oncedenSorgulananlar;

    TextToSpeech textToSpeech;

    @SuppressLint("Range")
    public ArrayList<Dil> dilleriGetir(){
        ArrayList<Dil> diller = new ArrayList<>();
        Cursor c = db.rawQuery("select * from Dil",null);
        while (c.moveToNext()){
            diller.add(new Dil(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("ad"))
            ));
        }
        return diller;
    }

    @SuppressLint("Range")
    public ArrayList<OncedenSorgulananlar> arananlariGetir(){
        ArrayList<OncedenSorgulananlar> oncedenSorgulananlar = new ArrayList<>();
        Cursor c = db.rawQuery("select * from OncedenSorgulananlar order by id desc",null);
        while (c.moveToNext()){
            oncedenSorgulananlar.add(new OncedenSorgulananlar(
                    c.getInt(c.getColumnIndex("id")),
                    c.getInt(c.getColumnIndex("source_lang_id")),
                    c.getInt(c.getColumnIndex("translate_lang_id")),
                    c.getString(c.getColumnIndex("kelime")),
                    c.getString(c.getColumnIndex("sonuc")),
                    c.getString(c.getColumnIndex("tarih"))
            ));
        }
        return oncedenSorgulananlar;
    }

    @SuppressLint("Range")
    public Dil diliGetir(String dil){
        Dil d = null;
        Cursor c = db.rawQuery("select * from Dil where ad='"+dil+"'",null);
        while (c.moveToNext()){
            d = new Dil(c.getInt(c.getColumnIndex("id")),c.getString(c.getColumnIndex("ad")));
        }
        return d;
    }
    @SuppressLint("Range")
    public Dil diliGetir(int dil){
        Dil d = null;
        Cursor c = db.rawQuery("select * from Dil where id="+dil,null);
        while (c.moveToNext()){
            d = new Dil(c.getInt(c.getColumnIndex("id")),c.getString(c.getColumnIndex("ad")));
        }
        return d;
    }

    public boolean arananlaraKaydet(String aranan,String sonuc,String tarih,int sourceLangId,int translateLangId){
        ContentValues cv = new ContentValues();
        cv.put("kelime",aranan);
        cv.put("sonuc",sonuc);
        cv.put("tarih",tarih);
        cv.put("source_lang_id",sourceLangId);
        cv.put("translate_lang_id",translateLangId);
        long l = db.insert("OncedenSorgulananlar",null,cv);
        if(l>0){
            return true;
        }else{
            return false;
        }
    }
    public boolean favoriyeEkle(int kelimeId){
        Cursor c = db.rawQuery("select * from FavoriSorgulanan where id="+kelimeId,null);
        if(c.getCount()==0){
            ContentValues cv = new ContentValues();
            cv.put("sorgulanan_id",kelimeId);
            long l = db.insert("FavoriSorgulanan",null,cv);
            if(l>0){
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }
    }

    public void aramayiSil(int aramaId){
        db.execSQL("delete from OncedenSorgulananlar where id="+aramaId);
    }

public void recyclerViewDoldur(){
    oncedenSorgulananlar = arananlariGetir();
    adapt = new RecceRecycleAdapt(oncedenSorgulananlar,getApplicationContext(),R.layout.arama_row,-1);
    adapt.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
        @Override
        public void onBindView(RecceRecycleAdapt.VH v, int position) {
            TextView tvAranan = v.itemView.findViewById(R.id.tvAranan);
            TextView tvSonuc = v.itemView.findViewById(R.id.tvSonuc);
            TextView tvTarih = v.itemView.findViewById(R.id.tvTarih);
            TextView tvArananDil = v.itemView.findViewById(R.id.tvArananDil);
            TextView tvSonucDil = v.itemView.findViewById(R.id.tvSonucDil);
            ImageView ivSeslendirSonuc = v.itemView.findViewById(R.id.ivSeslendirSonuc);
            ImageView ivSeslendirAranan = v.itemView.findViewById(R.id.ivSeslendirAranan);

            ivSeslendirSonuc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    textToSpeech.speak(tvSonuc.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                }
            });

            ivSeslendirAranan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    textToSpeech.speak(tvAranan.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                }
            });

            tvAranan.setText(oncedenSorgulananlar.get(position).getKelime());
            tvSonuc.setText(oncedenSorgulananlar.get(position).getSonuc());
            tvTarih.setText(oncedenSorgulananlar.get(position).getTarih());

            tvArananDil.setText(diliGetir(oncedenSorgulananlar.get(position).getSource_lang_id()).getAd());
            tvSonucDil.setText(diliGetir(oncedenSorgulananlar.get(position).getTranslate_lang_id()).getAd());

            v.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });

            v.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {

                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("İşlem");
                    adb.setCancelable(false);
                    adb.setMessage("Bir işlem seçiniz");
                    adb.setPositiveButton("Veriyi sil", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            aramayiSil(oncedenSorgulananlar.get(position).getId());
                            recyclerViewDoldur();
                        }
                    });
                    adb.setNegativeButton("Vazgeç", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    adb.setNeutralButton("Favoriye Ekle", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if(favoriyeEkle(oncedenSorgulananlar.get(position).getId())){
                                Toast.makeText(getApplicationContext(), "Favoriye eklendi.", Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(getApplicationContext(), "Favoriye eklenemedi.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    adb.create();
                    adb.show();

                    return false;
                }
            });
        }
    });
    recyclerViewArananlar.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
    recyclerViewArananlar.setAdapter(adapt);
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewArananlar = findViewById(R.id.recyclerViewArananlar);
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                textToSpeech.setLanguage(Locale.getDefault());
            }
        });

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        recyclerViewDoldur();

        diller = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,dilleriGetir());
        spSource = findViewById(R.id.spinnerSource);
        spResult = findViewById(R.id.spinnerTranslate);
        etResult = findViewById(R.id.etResult);
        etSearch = findViewById(R.id.etSearch);
        spResult.setAdapter(diller);
        spSource.setAdapter(diller);

        spResult.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                etResult.setText("");
                etSearch.setText("");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                etResult.setText("");
                etSearch.setText("");
            }
        });

        spSource.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @SuppressLint("Range")
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if(spSource.getSelectedItem().toString().equals(spResult.getSelectedItem().toString())){
                    etResult.setText("Kaynak dil ile Aranacak dil aynı olamaz !");
                }else{
                    Dil kaynakDil = diliGetir(spSource.getSelectedItem().toString());
                    Dil sonucDil = diliGetir(spResult.getSelectedItem().toString());
                    Cursor c = db.rawQuery(
                            "select * from Kelime where source_lang_id="+kaynakDil.getId() +" and  translate_lang_id="+sonucDil.getId()+" and source_keyword like '"+charSequence+"'",
                            null);
                    while (c.moveToNext()){
                        String sonuc = c.getString(c.getColumnIndex("translate_keyword"));
                        etResult.setText(sonuc);
                        SimpleDateFormat timeStampFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                        String dateStr = timeStampFormat.format(new Date());
                        arananlaraKaydet(charSequence.toString(),sonuc,dateStr,kaynakDil.getId(),sonucDil.getId());
                        recyclerViewDoldur();
                    }
                    if(c.getCount()==0){
                        etResult.setText("Not found keyword !");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.item_favoriler){
            Intent intent = new Intent(getApplicationContext(),FavoriActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}