package com.example.turkceingilizcesozluk.Model;

import java.io.Serializable;

public class FavoriSorgulanan implements Serializable {
    private int id;
    private int sorgulanan_id;

    public FavoriSorgulanan(int id, int sorgulanan_id) {
        this.id = id;
        this.sorgulanan_id = sorgulanan_id;
    }

    public FavoriSorgulanan() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSorgulanan_id() {
        return sorgulanan_id;
    }

    public void setSorgulanan_id(int sorgulanan_id) {
        this.sorgulanan_id = sorgulanan_id;
    }
}
