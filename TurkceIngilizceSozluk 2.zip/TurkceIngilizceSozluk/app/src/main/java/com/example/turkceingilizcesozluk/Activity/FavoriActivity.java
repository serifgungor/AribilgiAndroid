package com.example.turkceingilizcesozluk.Activity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.turkceingilizcesozluk.Adapter.RecceRecycleAdapt;
import com.example.turkceingilizcesozluk.Helper.DatabaseHelper;
import com.example.turkceingilizcesozluk.Model.Dil;
import com.example.turkceingilizcesozluk.Model.OncedenSorgulananlar;
import com.example.turkceingilizcesozluk.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class FavoriActivity extends AppCompatActivity {

    RecyclerView rcFavoriler;
    SQLiteDatabase db;
    DatabaseHelper dbHelper;
    ArrayList<OncedenSorgulananlar> favoriler;
    RecceRecycleAdapt adapter;
    TextToSpeech textToSpeech;

    @SuppressLint("Range")
    public Dil diliGetir(String dil){
        Dil d = null;
        Cursor c = db.rawQuery("select * from Dil where ad='"+dil+"'",null);
        while (c.moveToNext()){
            d = new Dil(c.getInt(c.getColumnIndex("id")),c.getString(c.getColumnIndex("ad")));
        }
        return d;
    }
    @SuppressLint("Range")
    public Dil diliGetir(int dil){
        Dil d = null;
        Cursor c = db.rawQuery("select * from Dil where id="+dil,null);
        while (c.moveToNext()){
            d = new Dil(c.getInt(c.getColumnIndex("id")),c.getString(c.getColumnIndex("ad")));
        }
        return d;
    }

    @SuppressLint("Range")
    public ArrayList<OncedenSorgulananlar> getFavoriler(){
        ArrayList<OncedenSorgulananlar> favoriler = new ArrayList<>();
        Cursor c = db.rawQuery("select os.* from FavoriSorgulanan fs,OncedenSorgulananlar os where fs.sorgulanan_id=os.id",null);
        while (c.moveToNext()){
            favoriler.add(new OncedenSorgulananlar(
                    c.getInt(c.getColumnIndex("id")),
                    c.getInt(c.getColumnIndex("source_lang_id")),
                    c.getInt(c.getColumnIndex("translate_lang_id")),
                    c.getString(c.getColumnIndex("kelime")),
                    c.getString(c.getColumnIndex("sonuc")),
                    c.getString(c.getColumnIndex("tarih"))
            ));
        }
        return favoriler;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favori);
        this.setTitle("Favoriler");

        rcFavoriler = findViewById(R.id.recyclerViewFavoriler);
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                textToSpeech.setLanguage(Locale.getDefault());
            }
        });

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        favoriler = getFavoriler();
        adapter = new RecceRecycleAdapt(favoriler,getApplicationContext(),R.layout.arama_row,-1);
        adapter.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
            @Override
            public void onBindView(RecceRecycleAdapt.VH v, int position) {
                TextView tvAranan = v.itemView.findViewById(R.id.tvAranan);
                TextView tvSonuc = v.itemView.findViewById(R.id.tvSonuc);
                TextView tvTarih = v.itemView.findViewById(R.id.tvTarih);
                TextView tvArananDil = v.itemView.findViewById(R.id.tvArananDil);
                TextView tvSonucDil = v.itemView.findViewById(R.id.tvSonucDil);
                ImageView ivSeslendirSonuc = v.itemView.findViewById(R.id.ivSeslendirSonuc);
                ImageView ivSeslendirAranan = v.itemView.findViewById(R.id.ivSeslendirAranan);

                ivSeslendirSonuc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        textToSpeech.speak(tvSonuc.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                    }
                });

                ivSeslendirAranan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        textToSpeech.speak(tvAranan.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                    }
                });

                tvAranan.setText(favoriler.get(position).getKelime());
                tvSonuc.setText(favoriler.get(position).getSonuc());
                tvTarih.setText(favoriler.get(position).getTarih());

                tvArananDil.setText(diliGetir(favoriler.get(position).getSource_lang_id()).getAd());
                tvSonucDil.setText(diliGetir(favoriler.get(position).getTranslate_lang_id()).getAd());



            }
        });
        rcFavoriler.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
        rcFavoriler.setAdapter(adapter);



    }
}