package com.serifgungor.yemektarifleri.Model;

import java.io.Serializable;

public class Favori implements Serializable {
    private int id;
    private int yemek_id;

    public Favori() {
    }

    public Favori(int id, int yemek_id) {
        this.id = id;
        this.yemek_id = yemek_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getYemek_id() {
        return yemek_id;
    }

    public void setYemek_id(int yemek_id) {
        this.yemek_id = yemek_id;
    }
}
