package com.serifgungor.yemektarifleri.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.yemektarifleri.Adapter.RecceRecycleAdapt;
import com.serifgungor.yemektarifleri.Helper.DatabaseHelper;
import com.serifgungor.yemektarifleri.Model.YemekKategorisi;
import com.serifgungor.yemektarifleri.R;

import java.io.IOException;
import java.util.ArrayList;

public class KategorilerActivity extends AppCompatActivity {
    ArrayList<YemekKategorisi> kategoriler = new ArrayList<>();
    RecyclerView recyclerView;
    RecceRecycleAdapt adapt;
    ImageView ivDonustur;
    boolean gecici = false;

    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    @SuppressLint("Range")
    public ArrayList<YemekKategorisi> kategorileriGetir(){
        ArrayList<YemekKategorisi> kategoriler = new  ArrayList<>();
        Cursor c = db.rawQuery("select * from YemekKategorileri",null);
        while (c.moveToNext()){
            kategoriler.add(new YemekKategorisi(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("adi")),
                    c.getString(c.getColumnIndex("resim"))
            ));
        }
        return kategoriler;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori);

        recyclerView = findViewById(R.id.recyclerViewKategori);
        ivDonustur = findViewById(R.id.ivDonustur);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //kategorileri veritabanından çağırdık
        kategoriler = kategorileriGetir();

        //adaptörü doldurduk
        adapt = new RecceRecycleAdapt(kategoriler,getApplicationContext(),R.layout.kategori_satir_goruntusu,0);
        adapt.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
            @Override
            public void onBindView(RecceRecycleAdapt.VH v, int position) {
                TextView tvBaslik = v.itemView.findViewById(R.id.tvKategoriBaslik);
                ImageView ivResim = v.itemView.findViewById(R.id.ivKategoriResim);
                tvBaslik.setText(kategoriler.get(position).getAdi());
                int resId = getResources().getIdentifier(kategoriler.get(position).getResim(),"drawable",getPackageName());
                //belirli bir dosya adını res klasörü altında drawable klasörü içerisinde arayıp, ilgili dosyanın referans adresini int olarak alır.
                ivResim.setImageResource(resId);

                v.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(),YemeklerActivity.class);
                        intent.putExtra("kategori",kategoriler.get(position));
                        startActivity(intent);
                    }
                });

            }
        });
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));

        ivDonustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(gecici==false){
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
                    gecici = true;
                    recyclerView.setAdapter(adapt);
                }else{
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
                    gecici = false;
                    recyclerView.setAdapter(adapt);
                }
            }
        });
        //adapterü recyclerview nesnesine atadık.
        recyclerView.setAdapter(adapt);

    }
}