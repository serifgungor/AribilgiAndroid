package com.serifgungor.vki_hesaplama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    RadioButton rdErkek,rdKadin;
    Button btnHesapla;
    EditText etBoy,etKilo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHesapla = findViewById(R.id.btnHesapla);
        etBoy = findViewById(R.id.etBoy);
        etKilo = findViewById(R.id.etKilo);
        rdErkek = findViewById(R.id.rdErkek);
        rdKadin = findViewById(R.id.rdKadin);

        btnHesapla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                float hFloatValue=Float.parseFloat(etBoy.getText().toString());
                float wFloatValue=Float.parseFloat(etKilo.getText().toString());
                float sonuc = wFloatValue/((hFloatValue / 100) * (hFloatValue / 100));
                float idealWeight = 0;

                if(rdErkek.isChecked()){
                    idealWeight = (float) ((hFloatValue-100)*0.89);
                }else if(rdKadin.isChecked()){
                    idealWeight = (float) ((hFloatValue-100)*0.94);
                }

                Intent i = new Intent(MainActivity.this, SonucActivity.class);
                i.putExtra("ideal_kilo", Float.toString(idealWeight));
                i.putExtra("suanki_oran", Float.toString(sonuc));
                startActivity(i);

                //Log.d("DURUM",Float.toString(idealWeight));
                //Log.d("DURUM",Float.toString(sonuc));

            }
        });
    }
}