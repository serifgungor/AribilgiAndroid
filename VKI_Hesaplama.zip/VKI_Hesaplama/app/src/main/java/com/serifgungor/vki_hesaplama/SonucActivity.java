package com.serifgungor.vki_hesaplama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SonucActivity extends AppCompatActivity {
    TextView tvIdealKilo,tvOran,tvDurum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonuc);
        tvIdealKilo = findViewById(R.id.tvIdealKilo);
        tvOran = findViewById(R.id.tvOran);
        tvDurum = findViewById(R.id.tvDurum);

        String ideal_kilo = getIntent().getStringExtra("ideal_kilo");
        Float suanki_oran = Float.parseFloat(getIntent().getStringExtra("suanki_oran"));

        tvIdealKilo.setText(""+ideal_kilo);
        tvOran.setText(""+suanki_oran);

        if(Math.round(suanki_oran) >0 && Math.round(suanki_oran)<=18.49){
            tvDurum.setText(getString(R.string.zayif));
        }else if(Math.round(suanki_oran) >18.49 && Math.round(suanki_oran)<=24.99){
            tvDurum.setText(getString(R.string.normal));
        }else if(Math.round(suanki_oran) >24.99 && Math.round(suanki_oran)<=29.99){
            tvDurum.setText(getString(R.string.fazlakilo));
        }else if(Math.round(suanki_oran) >29.99 && Math.round(suanki_oran)<=34.99){
            tvDurum.setText(getString(R.string.obez1kilo));
        }else if(Math.round(suanki_oran) >34.99 && Math.round(suanki_oran)<=44.99){
            tvDurum.setText(getString(R.string.obez2kilo));
        }else if(Math.round(suanki_oran) >44.99){
            tvDurum.setText(getString(R.string.obez3kilo));
        }
    }
}