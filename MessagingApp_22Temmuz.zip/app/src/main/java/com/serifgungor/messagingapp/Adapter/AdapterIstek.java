package com.serifgungor.messagingapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.messagingapp.Model.Istek;
import com.serifgungor.messagingapp.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdapterIstek extends BaseAdapter {

    private ArrayList<Istek> istekler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterIstek(ArrayList<Istek> istekler, Context context){
        this.istekler = istekler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return istekler.size();
    }

    @Override
    public Istek getItem(int position) {
        return istekler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = layoutInflater.inflate(R.layout.customrow_istek,null);

        CircleImageView photo = view.findViewById(R.id.ivIstekResim);
        Glide.with(view).load(istekler.get(position).getResimUrl()).into(photo);

        TextView tvAdSoyad = view.findViewById(R.id.tvIstekAdSoyad);
        tvAdSoyad.setText(istekler.get(position).getAdSoyad());

        TextView tvKabul = view.findViewById(R.id.tvKabul);
        TextView tvRed = view.findViewById(R.id.tvReddet);

        tvKabul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        tvRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return view;
    }
}
