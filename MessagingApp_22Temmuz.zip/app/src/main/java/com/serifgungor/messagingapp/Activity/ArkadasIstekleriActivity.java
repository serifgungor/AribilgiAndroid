package com.serifgungor.messagingapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.serifgungor.messagingapp.Adapter.AdapterIstek;
import com.serifgungor.messagingapp.Model.Arkadas;
import com.serifgungor.messagingapp.Model.Istek;
import com.serifgungor.messagingapp.Model.Kullanici;
import com.serifgungor.messagingapp.R;

import java.util.ArrayList;

public class ArkadasIstekleriActivity extends AppCompatActivity {

    ListView listViewIstekler;
    ArrayList<Istek> istekler = new ArrayList<>();
    AdapterIstek adapterIstek;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    SharedPreferences sp;
    SharedPreferences.Editor spe;

    public void init(){
        listViewIstekler = findViewById(R.id.listViewIstekler);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();
        this.getSupportActionBar().setTitle("Arkadaşlık İstekleri");
    }

    public void kisiBilgileriniGetir(String kullaniciId,String istekId){

        databaseReference.child("kullanicilar").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds:snapshot.getChildren()) {
                    Kullanici kullanici = ds.getValue(Kullanici.class);

                    if(kullanici.getKullanici_unique_id().equals(kullaniciId)){

                        Istek istek = new Istek();
                        istek.setIstekId(istekId);
                        istek.setAdSoyad(kullanici.getKullanici_ad_soyad());
                        istek.setResimUrl(kullanici.getKullanici_resim());
                        istekler.add(istek);
                        adapterIstek.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arkadas_istekleri);

        init();

        databaseReference.child("arkadaslar").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot ds:snapshot.getChildren()) {
                    Log.e("deneme",ds.toString());
                    Arkadas arkadas = ds.getValue(Arkadas.class);
                    if(arkadas.getArkadas_eklenen_id().equals(sp.getString("userid",""))){
                        //ben eklenmiş isem

                        kisiBilgileriniGetir(arkadas.getArkadas_ekleyen_id(),ds.getKey());

                    }
                }

                adapterIstek.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        adapterIstek = new AdapterIstek(istekler,getApplicationContext());
        listViewIstekler.setAdapter(adapterIstek);
    }
}