package com.serifgungor.messagingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.serifgungor.messagingapp.R;

public class MainActivity extends AppCompatActivity {

    ImageView ivAddUser,ivUserRequest;
    ListView listViewKisiler;

    public void init(){
        ivUserRequest = findViewById(R.id.ivUserRequest);
        ivAddUser = findViewById(R.id.ivAddUser);
        listViewKisiler = findViewById(R.id.listViewKisiler);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        ivAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ArkadasEklemeActivity.class));
            }
        });

        ivUserRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,ArkadasIstekleriActivity.class));
            }
        });

    }
}