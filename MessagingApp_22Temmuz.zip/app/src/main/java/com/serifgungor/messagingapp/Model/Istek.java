package com.serifgungor.messagingapp.Model;

public class Istek {
    private String istekId;
    private String adSoyad;
    private String resimUrl;

    public Istek() {
    }

    public Istek(String istekId, String adSoyad, String resimUrl) {
        this.istekId = istekId;
        this.adSoyad = adSoyad;
        this.resimUrl = resimUrl;
    }

    public String getIstekId() {
        return istekId;
    }

    public void setIstekId(String istekId) {
        this.istekId = istekId;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getResimUrl() {
        return resimUrl;
    }

    public void setResimUrl(String resimUrl) {
        this.resimUrl = resimUrl;
    }
}
