package com.serifgungor.messagingapp.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.serifgungor.messagingapp.Model.Kullanici;
import com.serifgungor.messagingapp.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class RegisterActivity extends AppCompatActivity {

    EditText etAdSoyad, etSifre, etMail, etTelefon;
    Button btnKayit,btnFotoSec,btnFotoYukle;
    CircleImageView ivProfilePhoto;
    FirebaseDatabase database;
    DatabaseReference dbRef;

    String uploadedUrl = "";


    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_PICK = 2;
    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private byte[] photoData;

    private void pickImageFromGallery() {
        Intent pickIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        startActivityForResult(pickIntent, REQUEST_IMAGE_PICK);
    }

    private byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        return baos.toByteArray();
    }

    private void uploadPhoto() {
        StorageReference photoRef = storageReference.child("photos/" + System.currentTimeMillis() + ".jpg");
        UploadTask uploadTask = photoRef.putBytes(photoData);


        uploadTask.addOnFailureListener(RegisterActivity.this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(RegisterActivity.this, "Upload Error: " +
                        e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }).addOnSuccessListener(RegisterActivity.this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                //Uri url = taskSnapshot.getDownloadUrl();
                Task<Uri> uri = taskSnapshot.getStorage().getDownloadUrl();
                while(!uri.isComplete());
                Uri url = uri.getResult();

               uploadedUrl = url.toString();
               Log.e("img",uploadedUrl);
            }
        });


    }

    public void init() {
        btnKayit = findViewById(R.id.btnRegisterNow);
        etAdSoyad = findViewById(R.id.etNameSurnameRegister);
        etSifre = findViewById(R.id.etPasswordRegister);
        etMail = findViewById(R.id.etEmailRegister);
        etTelefon = findViewById(R.id.etPhoneRegister);
        ivProfilePhoto = findViewById(R.id.ivProfilePhoto);
        btnFotoSec = findViewById(R.id.btnFotoSec);
        btnFotoYukle = findViewById(R.id.btnFotoYukle);

        database = FirebaseDatabase.getInstance();
        dbRef = database.getReference();

        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();

        btnFotoSec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickImageFromGallery();
            }
        });

        btnFotoYukle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (photoData != null) {
                    uploadPhoto();
                } else {
                    Toast.makeText(RegisterActivity.this, "Önce bir fotoğraf seçin.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!etAdSoyad.getText().toString().isEmpty()
                        &&
                        !etTelefon.getText().toString().isEmpty()
                        &&
                        !etMail.getText().toString().isEmpty()
                        &&
                        !etSifre.getText().toString().isEmpty()
                ){
                    String uniqueId = String.valueOf(new Date().getTime());
                    Kullanici kullanici = new Kullanici();
                    kullanici.setKullanici_unique_id(uniqueId);
                    kullanici.setKullanici_ad_soyad(etAdSoyad.getText().toString());
                    kullanici.setKullanici_mail(etMail.getText().toString());
                    kullanici.setKullanici_sifre(etSifre.getText().toString());
                    kullanici.setKullanici_phone_no(etTelefon.getText().toString());
                    kullanici.setKullanici_resim(uploadedUrl);

                    dbRef.child("kullanicilar").child(uniqueId).setValue(kullanici);
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(),"Boş alan bırakılamaz",Toast.LENGTH_LONG).show();
                }


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ivProfilePhoto.setImageBitmap(imageBitmap);
            photoData = convertBitmapToByteArray(imageBitmap);
        } else if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                ivProfilePhoto.setImageBitmap(bitmap);
                photoData = convertBitmapToByteArray(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}