package com.serifgungor.weatherapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.Queue;

public class MainActivity extends AppCompatActivity {
//6f4d70771e8c4c43ae2155549220801

    RequestQueue queue;
    StringRequest request;
    TextView tvIl, tvUlke, tvSicaklik;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvIl = findViewById(R.id.tvIl);
        tvUlke = findViewById(R.id.tvUlke);
        tvSicaklik = findViewById(R.id.tvSicaklik);
        String il = "ankara";

        queue = Volley.newRequestQueue(getApplicationContext());
        request = new StringRequest(
                Request.Method.GET,
                "http://api.weatherapi.com/v1/current.json?key=6f4d70771e8c4c43ae2155549220801&q="+il,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("havadurumu",response);
                        try {
                            JSONObject jo = new JSONObject(response);
                            JSONObject location = jo.getJSONObject("location");
                            JSONObject current = jo.getJSONObject("current");
                            String ulke = location.getString("country");
                            String il = location.getString("name");
                            String sicaklik = current.getString("temp_c");

                            tvIl.setText(il);
                            tvUlke.setText(ulke);
                            tvSicaklik.setText(sicaklik);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(request);
    }
}