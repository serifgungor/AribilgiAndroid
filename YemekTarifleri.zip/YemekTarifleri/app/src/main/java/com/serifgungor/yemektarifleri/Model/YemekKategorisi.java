package com.serifgungor.yemektarifleri.Model;

import java.io.Serializable;

public class YemekKategorisi implements Serializable {
    private int id;
    private String adi;
    private String resim;

    public YemekKategorisi() {

    }

    public YemekKategorisi(int id, String adi, String resim) {
        this.id = id;
        this.adi = adi;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }
}
