package com.serifgungor.yemektarifleri.Model;

import java.io.Serializable;

public class Yemek implements Serializable {
    private int id;
    private String adi;
    private int kategori_id;
    private int pisirme_suresi;
    private int servis_suresi;
    private int kac_kisilik;
    private String tarif_aciklamasi;
    private String resim;
    private String malzeme_listesi;

    public Yemek() {
    }

    public Yemek(int id, String adi, int kategori_id, int pisirme_suresi, int servis_suresi, int kac_kisilik, String tarif_aciklamasi, String resim, String malzeme_listesi) {
        this.id = id;
        this.adi = adi;
        this.kategori_id = kategori_id;
        this.pisirme_suresi = pisirme_suresi;
        this.servis_suresi = servis_suresi;
        this.kac_kisilik = kac_kisilik;
        this.tarif_aciklamasi = tarif_aciklamasi;
        this.resim = resim;
        this.malzeme_listesi = malzeme_listesi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public int getKategori_id() {
        return kategori_id;
    }

    public void setKategori_id(int kategori_id) {
        this.kategori_id = kategori_id;
    }

    public int getPisirme_suresi() {
        return pisirme_suresi;
    }

    public void setPisirme_suresi(int pisirme_suresi) {
        this.pisirme_suresi = pisirme_suresi;
    }

    public int getServis_suresi() {
        return servis_suresi;
    }

    public void setServis_suresi(int servis_suresi) {
        this.servis_suresi = servis_suresi;
    }

    public int getKac_kisilik() {
        return kac_kisilik;
    }

    public void setKac_kisilik(int kac_kisilik) {
        this.kac_kisilik = kac_kisilik;
    }

    public String getTarif_aciklamasi() {
        return tarif_aciklamasi;
    }

    public void setTarif_aciklamasi(String tarif_aciklamasi) {
        this.tarif_aciklamasi = tarif_aciklamasi;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getMalzeme_listesi() {
        return malzeme_listesi;
    }

    public void setMalzeme_listesi(String malzeme_listesi) {
        this.malzeme_listesi = malzeme_listesi;
    }
}
