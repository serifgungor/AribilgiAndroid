package com.serifgungor.yemektarifleri.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.yemektarifleri.Adapter.RecceRecycleAdapt;
import com.serifgungor.yemektarifleri.Helper.DatabaseHelper;
import com.serifgungor.yemektarifleri.Model.Yemek;
import com.serifgungor.yemektarifleri.Model.YemekKategorisi;
import com.serifgungor.yemektarifleri.R;

import java.io.IOException;
import java.util.ArrayList;

public class YemeklerActivity extends AppCompatActivity {
    YemekKategorisi yemekKategorisi;
    ArrayList<Yemek> yemekler = new ArrayList<>();
    SQLiteDatabase db;
    DatabaseHelper dbHelper;
    RecyclerView recyclerViewYemekler;
    RecceRecycleAdapt adapt;

    @SuppressLint("Range")
    public ArrayList<Yemek> yemekleriGetir(int kategoriId) {
        ArrayList<Yemek> yemek = new ArrayList<Yemek>();
//int id, String adi, int kategori_id, int pisirme_suresi, int servis_suresi, int kac_kisilik, String tarif_aciklamasi, String resim, String malzeme_listesi
        Cursor c = db.rawQuery("select * from Yemekler where kategori_id=" + kategoriId, null);
        while (c.moveToNext()) {
            yemek.add(new Yemek(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("adi")),
                    c.getInt(c.getColumnIndex("kategori_id")),
                    c.getInt(c.getColumnIndex("pisirme_suresi")),
                    c.getInt(c.getColumnIndex("servis_suresi")),
                    c.getInt(c.getColumnIndex("kac_kisilik")),
                    c.getString(c.getColumnIndex("tarif_aciklamasi")),
                    c.getString(c.getColumnIndex("resim")),
                    c.getString(c.getColumnIndex("malzeme_listesi"))
            ));
        }
        return yemek;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yemekler);

        yemekKategorisi = (YemekKategorisi) getIntent().getSerializableExtra("kategori");
        this.setTitle(yemekKategorisi.getAdi());

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
            yemekler = yemekleriGetir(yemekKategorisi.getId());
        } catch (IOException e) {
            e.printStackTrace();
        }

        recyclerViewYemekler = findViewById(R.id.recyclerViewYemekler);

        adapt = new RecceRecycleAdapt(yemekleriGetir(yemekKategorisi.getId()),getApplicationContext(),R.layout.yemek_satir_goruntusu,-1);
        adapt.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
            @Override
            public void onBindView(RecceRecycleAdapt.VH v, int position) {
                ImageView ivYemekRow = v.itemView.findViewById(R.id.ivYemekRow);
                TextView tvYemekRow = v.itemView.findViewById(R.id.tvYemekRow);
                TextView tvYemekRowPisirmeSuresi = v.itemView.findViewById(R.id.tvYemekRowPisirmeSuresi);
                TextView tvYemekRowServisSuresi = v.itemView.findViewById(R.id.tvYemekRowServisSuresi);
                TextView tvYemekRowKisiSayisi = v.itemView.findViewById(R.id.tvYemekRowKisiSayisi);

                int resId = getResources().getIdentifier(yemekler.get(position).getResim(),"drawable",getPackageName());
                ivYemekRow.setImageResource(resId);
                 tvYemekRow.setText(yemekler.get(position).getAdi());
                tvYemekRowServisSuresi.setText(""+yemekler.get(position).getServis_suresi());
                tvYemekRowPisirmeSuresi.setText(""+yemekler.get(position).getPisirme_suresi());
                tvYemekRowKisiSayisi.setText(""+yemekler.get(position).getKac_kisilik());

                v.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(),YemekDetayActivity.class);
                        intent.putExtra("yemek",yemekler.get(position));
                        startActivity(intent);
                    }
                });

            }
        });

        recyclerViewYemekler.setAdapter(adapt);
        recyclerViewYemekler.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));



        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}