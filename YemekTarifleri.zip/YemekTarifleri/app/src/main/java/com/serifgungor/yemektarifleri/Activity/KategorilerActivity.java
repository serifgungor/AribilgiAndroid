package com.serifgungor.yemektarifleri.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.yemektarifleri.Adapter.RecceRecycleAdapt;
import com.serifgungor.yemektarifleri.Helper.DatabaseHelper;
import com.serifgungor.yemektarifleri.Model.Yemek;
import com.serifgungor.yemektarifleri.Model.YemekKategorisi;
import com.serifgungor.yemektarifleri.R;

import java.io.IOException;
import java.util.ArrayList;

public class KategorilerActivity extends AppCompatActivity {
    ArrayList<YemekKategorisi> kategoriler = new ArrayList<>();
    ArrayList<Yemek> yemekler = new ArrayList<>();
    RecyclerView recyclerView;
    RecceRecycleAdapt adapt;
    ImageView ivDonustur;
    boolean gecici = false;

    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    Spinner spinnerDurum;
    ArrayAdapter<String> spinnerAdapter;

    @SuppressLint("Range")
    public ArrayList<YemekKategorisi> kategorileriGetir(){
        ArrayList<YemekKategorisi> kategoriler = new  ArrayList<>();
        Cursor c = db.rawQuery("select * from YemekKategorileri",null);
        while (c.moveToNext()){
            kategoriler.add(new YemekKategorisi(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("adi")),
                    c.getString(c.getColumnIndex("resim"))
            ));
        }
        return kategoriler;
    }

    @SuppressLint("Range")
    public ArrayList<Yemek> favoriYemekleriGetir(){
        //int id, String adi, int kategori_id, int pisirme_suresi, int servis_suresi, int kac_kisilik, String tarif_aciklamasi, String resim, String malzeme_listesi
        ArrayList<Yemek> yemekler = new ArrayList<>();
        Cursor c = db.rawQuery("select y.* from Favoriler f,Yemekler y where f.yemek_id=y.id",null);
        while (c.moveToNext()){
            yemekler.add(new Yemek(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("adi")),
                    c.getInt(c.getColumnIndex("kategori_id")),
                    c.getInt(c.getColumnIndex("pisirme_suresi")),
                    c.getInt(c.getColumnIndex("servis_suresi")),
                    c.getInt(c.getColumnIndex("kac_kisilik")),
                    c.getString(c.getColumnIndex("tarif_aciklamasi")),
                    c.getString(c.getColumnIndex("resim")),
                    c.getString(c.getColumnIndex("malzeme_listesi"))
            ));
        }
        return yemekler;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        recyclerView = findViewById(R.id.recyclerViewKategori);
        ivDonustur = findViewById(R.id.ivDonustur);
        spinnerDurum = findViewById(R.id.spinnerDurum);
        spinnerAdapter = new ArrayAdapter<>(
                getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,new String[]{"Kategoriler","Favoriler"}
        );
        spinnerDurum.setAdapter(spinnerAdapter);

        spinnerDurum.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                if(pos==0){
                    ivDonustur.setVisibility(View.VISIBLE);
                    //kategorileri veritabanından çağırdık
                    kategoriler = kategorileriGetir();

                    //adaptörü doldurduk
                    adapt = new RecceRecycleAdapt(kategoriler,getApplicationContext(),R.layout.kategori_satir_goruntusu,0);
                    adapt.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
                        @Override
                        public void onBindView(RecceRecycleAdapt.VH v, int position) {
                            TextView tvBaslik = v.itemView.findViewById(R.id.tvKategoriBaslik);
                            ImageView ivResim = v.itemView.findViewById(R.id.ivKategoriResim);
                            tvBaslik.setText(kategoriler.get(position).getAdi());
                            int resId = getResources().getIdentifier(kategoriler.get(position).getResim(),"drawable",getPackageName());
                            //belirli bir dosya adını res klasörü altında drawable klasörü içerisinde arayıp, ilgili dosyanın referans adresini int olarak alır.
                            ivResim.setImageResource(resId);

                            v.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(getApplicationContext(),YemeklerActivity.class);
                                    intent.putExtra("kategori",kategoriler.get(position));
                                    startActivity(intent);
                                }
                            });

                        }
                    });
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
                    //adapterü recyclerview nesnesine atadık.
                    recyclerView.setAdapter(adapt);
                }else if(pos==1){
                    ivDonustur.setVisibility(View.INVISIBLE);
                    yemekler = favoriYemekleriGetir();
                    adapt = new RecceRecycleAdapt(yemekler,getApplicationContext(),R.layout.yemek_satir_goruntusu,0);
                    adapt.setOnBindViewListener(new RecceRecycleAdapt.OnBindListener() {
                        @Override
                        public void onBindView(RecceRecycleAdapt.VH v, int position) {

                            ImageView ivYemekRow = v.itemView.findViewById(R.id.ivYemekRow);
                            TextView tvYemekRow = v.itemView.findViewById(R.id.tvYemekRow);
                            TextView tvYemekRowPisirmeSuresi = v.itemView.findViewById(R.id.tvYemekRowPisirmeSuresi);
                            TextView tvYemekRowServisSuresi = v.itemView.findViewById(R.id.tvYemekRowServisSuresi);
                            TextView tvYemekRowKisiSayisi = v.itemView.findViewById(R.id.tvYemekRowKisiSayisi);

                            int resId = getResources().getIdentifier(yemekler.get(position).getResim(),"drawable",getPackageName());
                            ivYemekRow.setImageResource(resId);
                            tvYemekRow.setText(yemekler.get(position).getAdi());
                            tvYemekRowServisSuresi.setText(""+yemekler.get(position).getServis_suresi());
                            tvYemekRowPisirmeSuresi.setText(""+yemekler.get(position).getPisirme_suresi());
                            tvYemekRowKisiSayisi.setText(""+yemekler.get(position).getKac_kisilik());

                            v.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(getApplicationContext(),YemekDetayActivity.class);
                                    intent.putExtra("yemek",yemekler.get(position));
                                    startActivity(intent);
                                }
                            });

                        }
                    });
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
                    //adapterü recyclerview nesnesine atadık.
                    recyclerView.setAdapter(adapt);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ivDonustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(gecici==false){
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
                    gecici = true;
                    recyclerView.setAdapter(adapt);
                }else{
                    recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
                    gecici = false;
                    recyclerView.setAdapter(adapt);
                }
            }
        });


    }
}