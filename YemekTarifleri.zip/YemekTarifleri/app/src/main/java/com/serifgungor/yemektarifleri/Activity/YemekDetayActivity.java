package com.serifgungor.yemektarifleri.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.yemektarifleri.Helper.DatabaseHelper;
import com.serifgungor.yemektarifleri.Model.Yemek;
import com.serifgungor.yemektarifleri.R;

import java.io.IOException;

public class YemekDetayActivity extends AppCompatActivity {

    Yemek yemek;
    ImageView ivResim;
    TextView tvBaslik, tvKisiSayisi,tvPisirmeSuresi,tvServisSuresi,tvTarifAciklama;
    LinearLayout linearMalzemeler;
    SQLiteDatabase db;
    DatabaseHelper dbHelper;


    public void malzemeleriGetir(String malzemeListesi){
        String[] malzemeler = malzemeListesi.split(",");
        for (int i = 0; i < malzemeler.length; i++) {
            CheckBox checkBox = new CheckBox(getApplicationContext());
            checkBox.setText(malzemeler[i]);
            linearMalzemeler.addView(checkBox);
        }
    }

    public void favoriyeEkle(){
        Cursor c = db.rawQuery("select * from Favoriler where yemek_id="+yemek.getId(),null);
        if(c.getCount()==0){
            db.execSQL("INSERT INTO Favoriler (yemek_id) VALUES ("+yemek.getId()+")");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yemek_detay);
        yemek = (Yemek) getIntent().getSerializableExtra("yemek");

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }


        this.setTitle(yemek.getAdi());
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ivResim = findViewById(R.id.ivYemekDetay);
        tvBaslik = findViewById(R.id.tvYemekDetayBaslik);
        tvKisiSayisi = findViewById(R.id.tvYemekDetayKisiSayisi);
        tvPisirmeSuresi = findViewById(R.id.tvYemekDetayPisirmeSuresi);
        tvServisSuresi = findViewById(R.id.tvYemekDetayServisSuresi);
        linearMalzemeler = findViewById(R.id.linearLayoutYemekDetayMalzemeler);
        tvTarifAciklama = findViewById(R.id.tvTarifAciklama);


        int resId = getResources().getIdentifier(yemek.getResim(),"drawable",getPackageName());
        ivResim.setImageResource(resId);
        tvBaslik.setText(yemek.getAdi());
        tvKisiSayisi.setText(""+yemek.getKac_kisilik());
        tvServisSuresi.setText(""+yemek.getServis_suresi());
        tvPisirmeSuresi.setText(""+yemek.getPisirme_suresi());
        tvTarifAciklama.setText(""+yemek.getTarif_aciklamasi());

        malzemeleriGetir(yemek.getMalzeme_listesi());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tarifdetay,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }else if(item.getItemId()==R.id.item_favoriye_ekle){
            favoriyeEkle();
            Toast.makeText(getApplicationContext(), "Favoriye Eklendi", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}