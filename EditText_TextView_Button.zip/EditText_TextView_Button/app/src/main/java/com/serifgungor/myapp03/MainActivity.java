package com.serifgungor.myapp03;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn;
    TextView isim;
    EditText etAd,etSoyad;

    void tanimla(){
        btn = findViewById(R.id.btnKaydet);
        isim = findViewById(R.id.tvAdSoyad);
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tanimla();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adsoyad = etAd.getText().toString() + " "+etSoyad.getText().toString();
                isim.setText(adsoyad);
            }
        });



    }

}