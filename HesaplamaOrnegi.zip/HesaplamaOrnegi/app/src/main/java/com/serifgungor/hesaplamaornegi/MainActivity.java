package com.serifgungor.hesaplamaornegi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etSayi1, etSayi2;
    Button btnHesapla;
    TextView tvTopla, tvCikar, tvCarp, tvBol;

    void doldur() {
        etSayi1 = findViewById(R.id.etSayi1);
        etSayi2 = findViewById(R.id.etSayi2);
        btnHesapla = findViewById(R.id.btnHesapla);
        tvTopla = findViewById(R.id.tvToplamaSonucu);
        tvCikar = findViewById(R.id.tvCikarmaSonucu);
        tvCarp = findViewById(R.id.tvCarpmaSonucu);
        tvBol = findViewById(R.id.tvBolmeSonucu);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        doldur();

        btnHesapla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double sayi1 = Double.parseDouble(etSayi1.getText().toString());
                double sayi2 = Double.parseDouble(etSayi2.getText().toString());
                double toplama,cikarma,carpma,bolme;

                toplama = sayi1+sayi2;
                cikarma = sayi1-sayi2;
                carpma = sayi1*sayi2;
                bolme = sayi1/sayi2;

                tvTopla.setText("Toplama sonucu: "+toplama);
                tvCikar.setText("Çıkarma sonucu: "+cikarma);
                tvCarp.setText("Çarpma sonucu: "+carpma);
                tvBol.setText("Bölme sonucu: "+bolme);

            }
        });

    }
}