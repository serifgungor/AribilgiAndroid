package com.serifgungor.telefonrehberi_room.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.telefonrehberi_room.Model.Kisi;
import com.serifgungor.telefonrehberi_room.R;

import java.util.ArrayList;

public class KisiAdapter extends BaseAdapter {

    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<Kisi> kisiler;

    public KisiAdapter(){}
    public KisiAdapter(ArrayList<Kisi> kisiler,Context context){
        this.kisiler = kisiler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kisiler.size();
    }

    @Override
    public Object getItem(int i) {
        return kisiler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.row_view,null);
        TextView tvAd = v.findViewById(R.id.tvAd);
        TextView tvSoyad = v.findViewById(R.id.tvSoyad);
        TextView tvGsm = v.findViewById(R.id.tvGsm);
        TextView tvNot = v.findViewById(R.id.tvNot);

        tvAd.setText(kisiler.get(i).ad);
        tvGsm.setText(kisiler.get(i).gsm);
        tvNot.setText(kisiler.get(i).not);
        tvSoyad.setText(kisiler.get(i).soyad);

        return v;
    }
}
