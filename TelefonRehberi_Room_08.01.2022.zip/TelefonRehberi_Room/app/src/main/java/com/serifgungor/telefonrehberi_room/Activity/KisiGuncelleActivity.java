package com.serifgungor.telefonrehberi_room.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.serifgungor.telefonrehberi_room.Model.AppDatabase;
import com.serifgungor.telefonrehberi_room.Model.Kisi;
import com.serifgungor.telefonrehberi_room.R;

public class KisiGuncelleActivity extends AppCompatActivity {

    EditText etGuncelleAd,etGuncelleSoyad,etGuncelleGsm,etGuncelleNot;
    Button btnGuncelleKisi;
    Kisi kisi;
    AppDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_guncelle);

        kisi = (Kisi) getIntent().getSerializableExtra("kisi");
        db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        etGuncelleAd = findViewById(R.id.etGuncelleAd);
        etGuncelleSoyad = findViewById(R.id.etGuncelleSoyad);
        etGuncelleGsm = findViewById(R.id.etGuncelleGsm);
        etGuncelleNot = findViewById(R.id.etGuncelleNot);
        btnGuncelleKisi = findViewById(R.id.btnGuncelle);

        etGuncelleAd.setText(kisi.ad);
        etGuncelleSoyad.setText(kisi.soyad);
        etGuncelleGsm.setText(kisi.gsm);
        etGuncelleNot.setText(kisi.not);

        btnGuncelleKisi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kisi.ad = etGuncelleAd.getText().toString();
                kisi.soyad = etGuncelleSoyad.getText().toString();
                kisi.gsm = etGuncelleGsm.getText().toString();
                kisi.not = etGuncelleNot.getText().toString();
                db.kisiDao().updateKisi(kisi);
                finish();
            }
        });

    }
}