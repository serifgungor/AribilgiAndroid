package com.serifgungor.telefonrehberi_room.Model;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Kisi.class},version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract KisiDao kisiDao();
}
