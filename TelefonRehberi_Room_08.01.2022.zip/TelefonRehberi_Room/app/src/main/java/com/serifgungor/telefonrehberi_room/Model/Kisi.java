package com.serifgungor.telefonrehberi_room.Model;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "kisiler")
public class Kisi implements Serializable {
    @ColumnInfo(name = "ad")
    public String ad;
    @ColumnInfo(name = "soyad")
    public String soyad;
    @ColumnInfo(name = "gsm")
    public String gsm;
    @ColumnInfo(name = "not")
    public String not;
    @PrimaryKey(autoGenerate = true)
    public int kisiId = 0;

    @NonNull
    @Override
    public String toString() {
        return "Kisi{" +
                "ad='" + ad + '\'' +
                ", soyad='" + soyad + '\'' +
                ", gsm='" + gsm + '\'' +
                ", not='" + not + '\'' +
                ", kisiId=" + kisiId +
                '}';
    }
}
