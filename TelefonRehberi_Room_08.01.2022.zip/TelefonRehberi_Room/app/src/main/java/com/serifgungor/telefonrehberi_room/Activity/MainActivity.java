package com.serifgungor.telefonrehberi_room.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.serifgungor.telefonrehberi_room.R;

public class MainActivity extends AppCompatActivity {
    Button btnEkle,btnListele;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEkle = findViewById(R.id.btnKisiEkle);
        btnListele = findViewById(R.id.btnKisiListele);

        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),KisiEkleActivity.class));
            }
        });

        btnListele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),KisiListeleActivity.class));
            }
        });
    }
}