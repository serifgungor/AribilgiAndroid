package com.serifgungor.telefonrehberi_room.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.serifgungor.telefonrehberi_room.Model.AppDatabase;
import com.serifgungor.telefonrehberi_room.Model.Kisi;
import com.serifgungor.telefonrehberi_room.R;

import java.util.List;

public class KisiEkleActivity extends AppCompatActivity {
    EditText etAd,etSoyad,etGsm,etNot;
    Button btnKisiEkle;
    AppDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_ekle);
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etGsm = findViewById(R.id.etGsm);
        etNot = findViewById(R.id.etNot);
        btnKisiEkle = findViewById(R.id.btnEkle);

        db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        btnKisiEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Kisi kisi = new Kisi();
                kisi.ad = etAd.getText().toString();
                kisi.soyad = etSoyad.getText().toString();
                kisi.gsm = etGsm.getText().toString();
                kisi.not = etNot.getText().toString();
                db.kisiDao().setKisi(kisi);

                List<Kisi> kisiList = db.kisiDao().getTumKisiler();
                Toast.makeText(getApplicationContext(),""+kisiList.size(),Toast.LENGTH_LONG).show();

            }
        });
    }
}