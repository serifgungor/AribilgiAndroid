package com.serifgungor.telefonrehberi_room.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.telefonrehberi_room.Adapter.KisiAdapter;
import com.serifgungor.telefonrehberi_room.Model.AppDatabase;
import com.serifgungor.telefonrehberi_room.Model.Kisi;
import com.serifgungor.telefonrehberi_room.R;

import java.io.Serializable;
import java.util.ArrayList;

public class KisiListeleActivity extends AppCompatActivity {
    ListView listView;
    KisiAdapter kisiAdapter;
    AppDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_listele);
        listView = findViewById(R.id.listViewKisiler);
        db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        ArrayList<Kisi> kisiler = (ArrayList<Kisi>) db.kisiDao().getTumKisiler();
        kisiAdapter = new KisiAdapter(kisiler,getApplicationContext());
        listView.setAdapter(kisiAdapter);

        /*
        Kisi k = db.kisiDao().getTumKisiler().get(i);
                k.ad = "KADİR";
                db.kisiDao().updateKisi(k);
         */

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                AlertDialog.Builder adb = new AlertDialog.Builder(KisiListeleActivity.this);
                adb.setTitle("Veriyi sil ?");
                adb.setMessage("Veri silinsin mi ?");
                adb.setPositiveButton("EVET", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        db.kisiDao().removeKisi(db.kisiDao().getTumKisiler().get(i));

                        ArrayList<Kisi> kisiler = (ArrayList<Kisi>) db.kisiDao().getTumKisiler();
                        kisiAdapter = new KisiAdapter(kisiler,getApplicationContext());
                        listView.setAdapter(kisiAdapter);
                    }
                });
                adb.setNegativeButton("GÜNCELLE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Intent intent = new Intent(getApplicationContext(),KisiGuncelleActivity.class);
                        intent.putExtra("kisi", (Serializable) db.kisiDao().getTumKisiler().get(i));
                        startActivity(intent);
                    }
                });
                adb.create();
                adb.show();

                return false;
            }
        });

    }
}