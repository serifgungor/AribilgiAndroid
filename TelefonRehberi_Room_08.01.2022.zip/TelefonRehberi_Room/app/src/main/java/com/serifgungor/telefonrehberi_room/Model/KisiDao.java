package com.serifgungor.telefonrehberi_room.Model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface KisiDao {
    @Query("SELECT * FROM kisiler")
    List<Kisi> getTumKisiler();
    @Insert
    void setKisi(Kisi kisi);
    @Delete
    void removeKisi(Kisi kisi);
    @Update
    void updateKisi(Kisi kisi);
}
