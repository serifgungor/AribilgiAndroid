package com.serifgungor.resimkutuphanesi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    ImageView ivResim;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivResim = findViewById(R.id.ivResim);
        btn = findViewById(R.id.btnTikla);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Glide
                    .with(getApplicationContext())
                    .load("https://www.aribilgi.com/wp-content/uploads/2020/09/cropped-logo.png")
                    .into(ivResim);



            }
        });
    }
}