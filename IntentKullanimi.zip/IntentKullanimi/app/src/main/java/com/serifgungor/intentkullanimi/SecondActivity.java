package com.serifgungor.intentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tvAdSoyad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvAdSoyad = findViewById(R.id.tvAdSoyad);

        //intent ile gelen veriyi yakalamak
        String adsoyad = getIntent().getStringExtra("abc");
        tvAdSoyad.setText(adsoyad);


    }
}