package com.example.turkceingilizcesozluk.Activity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.turkceingilizcesozluk.Helper.DatabaseHelper;
import com.example.turkceingilizcesozluk.Model.Dil;
import com.example.turkceingilizcesozluk.R;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    ArrayAdapter<Dil> diller;
    Spinner spSource,spResult;
    EditText etResult,etSearch;

    @SuppressLint("Range")
    public ArrayList<Dil> dilleriGetir(){
        ArrayList<Dil> diller = new ArrayList<>();
        Cursor c = db.rawQuery("select * from Dil",null);
        while (c.moveToNext()){
            diller.add(new Dil(
                    c.getInt(c.getColumnIndex("id")),
                    c.getString(c.getColumnIndex("ad"))
            ));
        }
        return diller;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        diller = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,dilleriGetir());
        spSource = findViewById(R.id.spinnerSource);
        spResult = findViewById(R.id.spinnerTranslate);
        etResult = findViewById(R.id.etResult);
        etSearch = findViewById(R.id.etSearch);
        spResult.setAdapter(diller);
        spSource.setAdapter(diller);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @SuppressLint("Range")
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    Cursor  c = db.rawQuery("select * from Kelime where source_keyword like '"+charSequence+"'",null);
                    while (c.moveToNext()){
                        etResult.setText(c.getString(c.getColumnIndex("translate_keyword")));
                    }
                    if(c.getCount()==0){
                        etResult.setText("Not found keyword !");
                    }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.item_favoriler){
            Toast.makeText(getApplicationContext(), "Favoriler", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}