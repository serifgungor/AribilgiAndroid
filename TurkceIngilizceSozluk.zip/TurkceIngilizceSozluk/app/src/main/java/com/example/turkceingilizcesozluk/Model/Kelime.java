package com.example.turkceingilizcesozluk.Model;

import java.io.Serializable;

public class Kelime implements Serializable {
    private int id;
    private int source_lang_id;
    private int translate_lang_id;
    private String source_keyword;
    private String translate_keyword;

    public Kelime() {
    }

    public Kelime(int id, int source_lang_id, int translate_lang_id, String source_keyword, String translate_keyword) {
        this.id = id;
        this.source_lang_id = source_lang_id;
        this.translate_lang_id = translate_lang_id;
        this.source_keyword = source_keyword;
        this.translate_keyword = translate_keyword;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSource_lang_id() {
        return source_lang_id;
    }

    public void setSource_lang_id(int source_lang_id) {
        this.source_lang_id = source_lang_id;
    }

    public int getTranslate_lang_id() {
        return translate_lang_id;
    }

    public void setTranslate_lang_id(int translate_lang_id) {
        this.translate_lang_id = translate_lang_id;
    }

    public String getSource_keyword() {
        return source_keyword;
    }

    public void setSource_keyword(String source_keyword) {
        this.source_keyword = source_keyword;
    }

    public String getTranslate_keyword() {
        return translate_keyword;
    }

    public void setTranslate_keyword(String translate_keyword) {
        this.translate_keyword = translate_keyword;
    }
}
