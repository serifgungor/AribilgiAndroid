package com.example.turkceingilizcesozluk.Model;

import java.io.Serializable;

public class OncedenSorgulananlar implements Serializable {
    private int id;
    private String kelime;
    private String sonuc;
    private String tarih;

    public OncedenSorgulananlar() {
    }

    public OncedenSorgulananlar(int id, String kelime, String sonuc, String tarih) {
        this.id = id;
        this.kelime = kelime;
        this.sonuc = sonuc;
        this.tarih = tarih;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKelime() {
        return kelime;
    }

    public void setKelime(String kelime) {
        this.kelime = kelime;
    }

    public String getSonuc() {
        return sonuc;
    }

    public void setSonuc(String sonuc) {
        this.sonuc = sonuc;
    }

    public String getTarih() {
        return tarih;
    }

    public void setTarih(String tarih) {
        this.tarih = tarih;
    }
}
