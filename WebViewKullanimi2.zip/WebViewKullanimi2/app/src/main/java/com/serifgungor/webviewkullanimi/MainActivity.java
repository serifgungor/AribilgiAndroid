package com.serifgungor.webviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    public void onClick(View view) {
        String website = "";
        switch (view.getId()){
            case R.id.btnAriBilgi:
                website = "https://aribilgi.com";
                break;
            case R.id.btnFacebook:
                website = "https://facebook.com";
                break;
            case R.id.btnHaberler:
                website = "https://haberler.com";
                break;
            case R.id.btnTwitter:
                website = "https://twitter.com";
                break;
            default:
                website = "https://aribilgi.com";
                break;
        }
        Intent i = new Intent(MainActivity.this,WebViewActivity.class);
        i.putExtra("url",website);
        startActivity(i);

    }

    Button btnHaberler,btnTwitter,btnFacebook,btnAriBilgi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnHaberler = findViewById(R.id.btnHaberler);
        btnTwitter = findViewById(R.id.btnTwitter);
        btnFacebook = findViewById(R.id.btnFacebook);
        btnAriBilgi = findViewById(R.id.btnAriBilgi);
        btnHaberler.setOnClickListener(this);
        btnFacebook.setOnClickListener(this);
        btnTwitter.setOnClickListener(this);
        btnAriBilgi.setOnClickListener(this);

    }

}